"""This module runs the srfm with inputs from the oxharp retrieval.


- Name: oxharp_main
- Parent package: srfm
- Author: Antonin Knizek
- Contributors:
- Date: 21 Jan 2025
"""

import numpy as np
import matplotlib.pyplot as plt
from . import utilities
from . import forward_model
from . import rfm_functions
from . import layer
import os
import sys
import datetime
import warnings
from pathlib import Path
import importlib.util
from . import rfm_helper
from .input_schema import validate_oxharp_inputs
from .main import (
    _add_grey_body_optical_depth,
    _calculate_output_utau,
    _calculate_optical_layers,
    _construct_and_validate_optical_layers,
    _grey_body_effective_parameters,
    _interpolate_grey_body_optical_depths,
    _interpolate_particle_block,
    _plot_retained_spectral_outputs,
    _prepare_boundary_spectral_fields,
    _prepare_solar_spectral_irradiance,
    _set_spectral_boundary_inputs,
    _resolve_output_geometry,
    _resolve_retained_outputs,
    _write_srfm_netcdf,
    _write_spectral_text,
)


@utilities.show_runtime
def run_srfm(inp):
    """Run the memory-efficient SRFM pathway for OXHARP inputs.

    Copies srfm.main.run_srfm, but is tailored to run with inputs from oxharp
    (used with the oxharp retrieval).

    Args:
        inp (obj): Instance of inputs.Inputs.

    Returns:
        model_SRFM (obj): Instance of forward_model.SRFM.

    Raises:
        TypeError: If ``inp`` does not provide a ``values`` mapping.
        InputValidationError: If configured OXHARP inputs are invalid.
        RuntimeError: If RFM capture or a native model calculation fails.
        ValueError: If spectral, atmospheric, or output geometry is inconsistent.

    """
    if not hasattr(inp, "values"):
        raise TypeError("run_srfm expects an Inputs-like object with a values mapping.")
    inp.values = validate_oxharp_inputs(inp.values)
    ########################################################################################
    # set final grid to interpolate to
    ########################################################################################
    npts = (
        int(
            np.floor(
                (inp.values["fin_wvnmhi"] - inp.values["fin_wvnmlo"])
                / inp.values["fin_res"]
            )
        )
        + 1
    )  # expected number of points in the grid
    fin_grid = inp.values["fin_wvnmlo"] + np.arange(npts) * inp.values["fin_res"]

    ########################################################################################
    # specify spectral calculation grid
    ########################################################################################
    spec_res = inp.values["spc_res"]  # model spectral resolution,[spec_units]
    low_spc = inp.values["spc_wvnmlo"]  # model start wavenumber (lower), [spec_units]
    upp_spc = inp.values["spc_wvnmhi"]  # model end wavenumber (upper), [spec_units]
    spec_units = inp.values["spc_units"]  # includes constant resolving power

    RFM_wvnm, wvls = utilities.calc_grids(low_spc, upp_spc, spec_res, spec_units)

    prepared_albedo, prepared_custom_solar = _prepare_boundary_spectral_fields(
        inp.values, RFM_wvnm
    )
    scat_lyrs, prescribed_lyrs, gbc_lyrs = _construct_and_validate_optical_layers(
        inp.values, RFM_wvnm
    )
    _calculate_optical_layers(
        scat_lyrs,
        gbc_lyrs,
        inp.values.get("retain_phase_functions", False),
    )
    particle_lyrs = {**scat_lyrs, **prescribed_lyrs}

    os.makedirs(inp.values["results_fldr"], exist_ok=True)
    rfm_grid_fname = rfm_functions.construct_rfm_grid_file(
        RFM_wvnm, filename="grid.spc", rfm_fldr=inp.values["results_fldr"]
    )

    ########################################################################################
    # prepare atmospheric layer structure
    ########################################################################################

    # define some requested output levels
    if "levels" in inp.values.keys():
        levels = inp.values["levels"]
    else:
        levels = [
            0.0,
            1.0,
            2.0,
            3.0,
            4.0,
            5.0,
            6.0,
            7.0,
            8.0,
            9.0,
            10.0,
            11.0,
            12.0,
            13.0,
            14.0,
            15.0,
            16.0,
            17.0,
            18.0,
            19.0,
            20.0,
            21.0,
            22.0,
            23.0,
            24.0,
            25.0,
            27.5,
            30.0,
            32.5,
            35.0,
            37.5,
            40.0,
            42.5,
            45.0,
            47.5,
            50.0,
            55.0,
            60.0,
            65.0,
            70.0,
            75.0,
            80.0,
            85.0,
            90.0,
            95.0,
            100.0,
            115.0,
            120.0,
        ]

    # define tracker array for atmospheric structure
    track_lev = [None for i in levels]

    # add upper and lower particle layer boundaries, delete any levels "within" the layer
    for lyr in scat_lyrs.keys():
        levels, track_lev = utilities.add_lyr_from_Layer(
            lev=levels, track_lev=track_lev, new_lyr=scat_lyrs[lyr]
        )

    for lyr in prescribed_lyrs:
        levels, track_lev = utilities.add_lyr_from_Layer(
            lev=levels, track_lev=track_lev, new_lyr=prescribed_lyrs[lyr]
        )

    for lyr in gbc_lyrs:
        levels, track_lev = utilities.add_lyr_from_Layer(
            lev=levels, track_lev=track_lev, new_lyr=gbc_lyrs[lyr]
        )

    # convert the tracking levels array to a tracking layers array
    track_lyr = utilities.track_lev_to_track_lyr(track_lev)
    track_lyr = track_lyr[::-1]

    ########################################################################################
    # prepare and call RFM
    ########################################################################################
    # RFM global config
    rfm_config = inp.values["rfm_config"]

    # RFM driver table
    driver_inputs = inp.values["driver_inputs"]
    driver_inputs["tangent"] = (str(inp.values["zen_sec"]),)
    driver_inputs["lev"] = tuple(str(val) for val in levels)

    if "btemp" in inp.values:
        driver_inputs["sfc"] = (f"TEMSFC={inp.values['btemp']}",)

    # initialize RFM model class
    model_RFM = forward_model.RFM()

    # print current status:
    print(model_RFM.status)

    # run rfm
    rfm_run_result = rfm_helper.rfm_main(
        configuration=rfm_config,
        driver_inputs=driver_inputs,
        levels=levels,
        rfm_out_fldr=inp.values["results_fldr"],
    )
    model_RFM.rfm_run_result = rfm_run_result
    if rfm_run_result.optical_depth_grid is None:
        raise RuntimeError("RFM capture did not return a compact optical-depth grid.")
    model_RFM.rfm_output = rfm_run_result.optical_depth_grid

    # print current status:
    print(model_RFM.status)

    RFM_wvnm = model_RFM.rfm_output.wavenumber
    wvls = (1.0 / RFM_wvnm) * 1e4
    if isinstance(prepared_albedo, float):
        surface_albedo = prepared_albedo
    else:
        surface_albedo = prepared_albedo.interpolate(RFM_wvnm)
    grey_body_optical_depths = _interpolate_grey_body_optical_depths(
        gbc_lyrs, wvls
    )

        # Prepare dict with layer parameters to be saved in the output
    layer_attrs = (
        "name",
        "low_spc",
        "upp_spc",
        "spec_units",
        "res",
        "mass_loading",
        "n",
        "r",
        "s",
        "effective_radius",
        "alpha",
        "b",
        "gamma",
        "median_radius",
        "truncate",
        "rho",
        "s_a_den",
        "v_den",
        "dist_type",
        "comp",
        "center_alt",
        "thick",
        "alt_low",
        "alt_upp",
        "radii",
        "eta",
        "phase_quad_N",
        "phase_quad_type",
        "radii_quad_type",
        "leg_coeffs",
        "leg_coeffs_type",
        "multiprocess",
    )

    effective_params = dict(inp.values)
    effective_params["scat_lyrs_inputs"] = {
        lyr: {"layer_type": "mie"}
        | {
            attr: getattr(scat_lyrs[lyr], attr)
            for attr in layer_attrs
            if hasattr(scat_lyrs[lyr], attr)
        }
        for lyr in scat_lyrs
    }
    effective_params["prescribed_lyrs_inputs"] = {
        lyr: prescribed_lyrs[lyr].source_metadata() for lyr in prescribed_lyrs
    }
    effective_params["gbc_lyrs_inputs"] = _grey_body_effective_parameters(gbc_lyrs)
    effective_params["albedo"] = (
        prepared_albedo
        if isinstance(prepared_albedo, float)
        else prepared_albedo.provenance()
    )
    if prepared_custom_solar is not None:
        effective_params["solar_spectrum"] = prepared_custom_solar.provenance()

    ########################################################################################
    # prepare DISORT common variables
    ########################################################################################

    # initialize DISORT model class
    model_DISORT = forward_model.DISORT(retain_history=False)

    # check if number of columns and wavelengths match
    if model_RFM.rfm_output.differential_tau.shape[0] != len(wvls):
        raise ValueError(
            f"Number of RFM and scattering wavelengths don't match "
            f"({model_RFM.rfm_output.differential_tau.shape[0]} optical-depth rows "
            f"vs {len(wvls)} scattering wavelengths)."
        )
    output_values, altitude_rows = _resolve_output_geometry(
        inp.values["out_fmt"],
        inp.values["out"],
        inp.values["out_toa"],
        model_RFM.rfm_output,
    )

    # set disort_input parameters common to all loop iterations
    # these need to be set first:
    nmom = inp.values["nmom"]
    for particle_layer in particle_lyrs.values():
        nmom = max(nmom, particle_layer.required_nmom)

    model_DISORT.set_maxcmu(inp.values["maxcmu"])

    model_DISORT.set_maxmom(nmom)
    if nmom < model_DISORT.disort_input["maxcmu"]:
        model_DISORT.set_maxmom(model_DISORT.disort_input["maxcmu"])
    nmom = model_DISORT.disort_input["maxmom"]

    model_DISORT.set_maxumu(inp.values["maxumu"])
    model_DISORT.set_maxphi(inp.values["maxphi"])
    model_DISORT.set_maxulv(len(output_values))
    effective_params["maxulv"] = len(output_values)

    # now the rest
    model_DISORT.set_usrang(inp.values["usrang"])
    model_DISORT.set_usrtau(inp.values["usrtau"])
    model_DISORT.set_ibcnd(inp.values["ibcnd"])
    model_DISORT.set_onlyfl(inp.values["onlyfl"])
    # model_DISORT.set_prnt([True, True, True, False, False])
    model_DISORT.set_prnt(inp.values["prnt"])
    model_DISORT.set_plank(inp.values["planck"])
    model_DISORT.set_lamber(inp.values["lamber"])
    model_DISORT.set_deltamplus(inp.values["deltamplus"])
    model_DISORT.set_do_pseudo_sphere(inp.values["do_pseudo_sphere"])

    model_DISORT.set_fisot(inp.values["fisot"])
    if isinstance(surface_albedo, float):
        model_DISORT.set_albedo(surface_albedo)

    model_DISORT.set_temis(inp.values["temis"])
    model_DISORT.set_earth_radius(inp.values.get("earth_radius", 6371.0))
    model_DISORT.set_rhoq(
        np.zeros(
            shape=(
                int(model_DISORT.disort_input["maxcmu"] / 2),
                int(model_DISORT.disort_input["maxcmu"] / 2 + 1),
                int(model_DISORT.disort_input["maxcmu"]),
            )
        )
    )
    model_DISORT.set_rhou(
        np.zeros(
            shape=(
                model_DISORT.disort_input["maxumu"],
                int(model_DISORT.disort_input["maxcmu"] / 2 + 1),
                model_DISORT.disort_input["maxcmu"],
            )
        )
    )
    model_DISORT.set_rho_accurate(
        np.zeros(
            shape=(
                model_DISORT.disort_input["maxumu"],
                model_DISORT.disort_input["maxphi"],
            )
        )
    )
    model_DISORT.set_bemst(
        np.zeros(shape=(int(model_DISORT.disort_input["maxcmu"] / 2)))
    )
    model_DISORT.set_emust(np.zeros(shape=(model_DISORT.disort_input["maxumu"])))
    model_DISORT.set_accur(0)
    ########################################################################################
    # prepare solar spectrum
    ########################################################################################
    # set date
    if "date" in inp.values:
        if isinstance(inp.values["date"], datetime.datetime):
            date = inp.values["date"]
        elif isinstance(inp.values["date"], tuple) and len(inp.values["date"]) == 3:
            date = datetime.datetime(*inp.values["date"])
        else:
            raise ValueError(f"""date must be a tuple of len 3 or a 
                datetime.datetime object. The current date is 
                {inp.values["date"]} and is a type 
                {type(inp.values["date"])}.""")

    else:
        date = datetime.datetime(
            2025, 3, 23
        )  # default date, approx spring equinox, avg Earth-Sun dist
    year_day = date.timetuple().tm_yday

    solar_spc = _prepare_solar_spectral_irradiance(
        prepared_custom_solar,
        RFM_wvnm,
        year_day,
        sun=inp.values["sun"],
    )
    if inp.values["sun"] == True:
        # get incoming solar beam polar angle for DISORT
        model_DISORT.set_umu0(inp.values["sza_cos"])
        model_DISORT.set_phi0(inp.values["saa"])

    else:
        model_DISORT.set_umu0(1)
        model_DISORT.set_phi0(0)

    model_DISORT.set_umu([inp.values["zen_cos"]])
    model_DISORT.set_phi([inp.values["azi"]])

    # initialize disort input arrays for output variables from a single run
    model_DISORT.initialize_disort_output_arrays()

    ########################################################################################
    # set DISORT DISOBRDF variables
    ########################################################################################

    # TBD

    ########################################################################################
    # prepare SRFM common variables
    ########################################################################################
    model_SRFM = forward_model.SRFM()
    model_SRFM.set_wvnm(RFM_wvnm)
    model_SRFM.set_wvls(wvls)
    requested_outputs, runtime_outputs = _resolve_retained_outputs(inp.values)
    model_SRFM.initialize_srfm_output_arrays_from_disort(
        model_DISORT, retain_outputs=runtime_outputs
    )
    model_SRFM.output_format = inp.values["out_fmt"]
    model_SRFM.output_values = output_values
    model_SRFM.output_polar_angles = np.asarray([inp.values["zen"]], dtype=float)
    model_SRFM.output_azimuthal_angles = np.asarray([inp.values["azi"]], dtype=float)

    # track progress
    pct = [
        1,
        2,
        5,
        10,
        20,
        30,
        40,
        50,
        60,
        70,
        80,
        90,
        100,
    ]  # percent completed to report
    pct_val = [RFM_wvnm[int(i * len(RFM_wvnm) / 100 - 1)] for i in pct]

    ########################################################################################
    # set dynamic variables and run DISORT
    ########################################################################################
    scattering_block_size = inp.values.get("scattering_block_size", 10000)
    particle_block = {}
    particle_block_start = 0
    skipped_scattering = {
        layer_name: {"count": 0, "first": None, "last": None}
        for layer_name in particle_lyrs
    }
    for wvl_idx, (wvnm, wvl, tau_g) in enumerate(
        zip(RFM_wvnm, wvls, model_RFM.rfm_output.differential_tau)
    ):
        if particle_lyrs and wvl_idx % scattering_block_size == 0:
            particle_block_start = wvl_idx
            block_stop = min(wvl_idx + scattering_block_size, len(wvls))
            particle_block = _interpolate_particle_block(
                particle_lyrs,
                RFM_wvnm[wvl_idx:block_stop],
                nmom,
            )
        block_index = wvl_idx - particle_block_start

        # track progress
        if wvnm in pct_val:
            val_idx = pct_val.index(wvnm)
            print(f"Running main DISORT loop. {pct[val_idx]}% done...")

        #        model_DISORT.set_header(f"Now starting calculation for {col} cm-1.")
        model_DISORT.set_header(
            "NO HEADER"
        )  # the string "NO HEADER" will cause no printout
        model_DISORT.set_wvnm(wvnm)
        model_DISORT.set_wvl(wvl)

        tau_g = _add_grey_body_optical_depth(
            tau_g,
            track_lyr,
            grey_body_optical_depths,
            wvl_idx,
        )

        # layer optical depths from Rayleigh scattering
        #    tau_R = np.zeros(shape=(tau_g.shape))
        tau_R = utilities.calc_Rayleigh_opt_depths(
            ps=model_RFM.rfm_output.pressure_lower[-1],
            pu=model_RFM.rfm_output.pressure_upper,
            pl=model_RFM.rfm_output.pressure_lower,
            l=wvnm,
        )

        # particle layer optical depths (from particle scattering)
        tau_p = np.zeros(shape=(len(tau_g)))
        for lyr in particle_lyrs:
            tau_p[track_lyr.index(lyr)] = particle_block[lyr][
                "particle_optical_depth"
            ][block_index]

        # particle layer single scatter albedo
        w_p = np.zeros(shape=(len(tau_g)))
        for lyr in particle_lyrs:
            w_p[track_lyr.index(lyr)] = particle_block[lyr][
                "single_scattering_albedo"
            ][block_index]

        dtauc_tot = utilities.calc_tot_dtauc(tau_g=tau_g, tau_R=tau_R, tau_p=tau_p)
        dtauc_tot = np.maximum(np.asarray(dtauc_tot, dtype=float), 0.0)

        # truncate optical depths
        threshold_od = 1e-8  # threshold at which to truncate optical depths
        significant_layers = np.flatnonzero(dtauc_tot > threshold_od)
        idx = int(significant_layers[0]) if significant_layers.size else 0

        utau = _calculate_output_utau(
            inp.values["out_fmt"],
            output_values,
            altitude_rows,
            dtauc_tot,
            idx,
        )
        model_DISORT.set_utau(utau)

        dtauc_tot = dtauc_tot[idx:]
        tau_g = tau_g[idx:]
        tau_R = tau_R[idx:]
        tau_p = tau_p[idx:]
        w_p = w_p[idx:]
        track_lyr_local = track_lyr[idx:]

        # set layer optical depths
        model_DISORT.set_dtauc_manually(dtauc=dtauc_tot)
        model_DISORT.disort_input["dtauc"][model_DISORT.disort_input["dtauc"] < 0] = 0

        # set maxcly based on current length of tau_g
        model_DISORT.set_maxcly(len(dtauc_tot))

        ## set some maxcly-dependent DISORT input variables

        # set and truncate temper
        model_DISORT.set_temper_from_rfm(model_RFM)
        model_DISORT.disort_input["temper"] = model_DISORT.disort_input["temper"][idx:]

        # set bottom boundary temperature
        if "btemp" in inp.values:
            model_DISORT.set_btemp(inp.values["btemp"])
        else:
            model_DISORT.set_btemp(model_DISORT.disort_input["temper"][-1])

        # set top boundary temperature
        if "ttemp" in inp.values:
            model_DISORT.set_ttemp(inp.values["ttemp"])
        else:
            model_DISORT.set_ttemp(model_DISORT.disort_input["temper"][0])

        model_DISORT.set_h_lyr(
            np.zeros(shape=(model_DISORT.disort_input["maxcly"] + 1))
        )

        # set single scatter albedo
        model_DISORT.set_ssalb(tau_g=tau_g, tau_R=tau_R, tau_p=tau_p, w_p=w_p)

        particle_moments = {}
        for lyr in particle_lyrs:
            layer_tau = particle_block[lyr]["particle_optical_depth"][block_index]
            layer_ssalb = particle_block[lyr]["single_scattering_albedo"][block_index]
            if layer_tau * layer_ssalb < threshold_od:
                skipped = skipped_scattering[lyr]
                skipped["count"] += 1
                skipped["first"] = wvnm if skipped["first"] is None else skipped["first"]
                skipped["last"] = wvnm
            else:
                coefficients = particle_block[lyr][
                    "normalized_legendre_coefficients"
                ][block_index].copy()
                if (
                    abs(coefficients[0] - 1.0)
                    > layer.NORMALIZED_MOMENT_TOLERANCE
                ):
                    raise RuntimeError(
                        "Something is wrong with the phase function. The first "
                        f"coefficient is {coefficients[0]}, but should be 1.0. "
                        "Try increasing number of quadrature points."
                    )
                coefficients[0] = 1.0
                particle_moments[track_lyr_local.index(lyr)] = coefficients

        model_DISORT.set_mixed_pmom(
            tau_R=tau_R,
            w_p=w_p,
            tau_p=tau_p,
            particle_moments=particle_moments,
            prec=inp.values["disort_precision"],
        )
        #    print(model_DISORT.disort_input["pmom"]).shape

        # set wavenumber range for DISORT (for Planck function)
        model_DISORT.set_wvnm_range(wvnm - 0.5, wvnm + 0.5)

        _set_spectral_boundary_inputs(
            model_DISORT,
            wvl_idx,
            surface_albedo,
            solar_spc,
            sun=inp.values["sun"],
        )
        #    model_DISORT.set_fbeam(0.1)

        # run disort input tests
        # see main.py for comment
        #        model_DISORT.test_disort_input_format()
        #        model_DISORT.test_disort_input_integrity()

        # call DISOBRDF
        #    model_DISORT.run_disobrdf(prec=inp.values["disort_precision"],
        #                              debug=False,
        #                              brdf_type=2, # Cox-Munk
        #                              brdf_arg=[1,1.34,False,0], # wind speed, water refractive index, do_shadow
        #                              nmug=200) # number of quadrature angles
        # run disort
        disort_result = model_DISORT.run_disort(prec=inp.values["disort_precision"],adjust_maxcmu=inp.values["adjust_maxcmu"],)

        # store result in SRFM()
        model_SRFM.store_disort_result(disort_result, wvl_idx)

        # print current status
    #    print(model_DISORT.status)
    print("Main DISORT loop finished.")
    for layer_name, skipped in skipped_scattering.items():
        if skipped["count"]:
            warnings.warn(
                f"Particle layer {layer_name!r} was below scattering optical-depth threshold "
                f"{threshold_od:g} at {skipped['count']} wavenumbers from "
                f"{skipped['first']:g} to {skipped['last']:g} cm-1; particle "
                "scattering was omitted there.",
                stacklevel=2,
            )

    # convolve final radiance spectrum with iasi instrument line shape
    if inp.values["convolve_iasi"] == True:
        model_SRFM.convolve_with_iasi(inp.values["iasi_ils"])

    # interpolate resulting bbt and radiances to final grid
    model_SRFM.interp(fin_grid)

    if "bbt" in requested_outputs:
        model_SRFM.calc_bbt()
    if "uu" not in requested_outputs and hasattr(model_SRFM, "uu"):
        delattr(model_SRFM, "uu")
        model_SRFM.retained_outputs = frozenset(
            set(model_SRFM.retained_outputs) - {"uu"}
        )

    ########################################################################################
    # (optional) save spectrum to file
    ########################################################################################
    if inp.values["out_mode"] == "txt":
        if "bbt" in requested_outputs:
            _write_spectral_text(
                os.path.join(inp.values["results_fldr"], "bbt.txt"),
                model_SRFM.wvnm,
                model_SRFM.bbt,
                "Brightness temperature (K)",
            )

        if "uu" in requested_outputs:
            _write_spectral_text(
                os.path.join(inp.values["results_fldr"], "rad.txt"),
                model_SRFM.wvnm,
                model_SRFM.uu,
                "Radiance (W m-2 sr-1 cm)",
            )

    elif inp.values["out_mode"] == "netcdf":
        out_nm = os.path.join(
            inp.values["results_fldr"], inp.values.get("out_fname") or "srfm.nc"
        )
        _write_srfm_netcdf(
            out_nm,
            model_SRFM,
            inp.values["retain_outputs"],
            effective_params,
            RFM_wvnm,
            particle_lyrs,
            grey_body_layers=gbc_lyrs,
            surface_albedo=surface_albedo,
            solar_spectral_irradiance=solar_spc,
            nmom=nmom,
            scattering_block_size=scattering_block_size,
        )

    elif inp.values["out_mode"] == None:
        pass

    if inp.values.get("base_plots", False):
        _plot_retained_spectral_outputs(
            model_SRFM,
            inp.values["results_fldr"],
            inp.values["retain_outputs"],
            inp.values.get("show_plots", False),
        )

    return model_SRFM
