MODULE LEXIST_FNC
CONTAINS
LOGICAL FUNCTION LEXIST ( FILNAM )
!
! VERSION
!   12DEC23 AD Checked.
!   01MAY17 AD F90 conversion. Checked.
!
! DESCRIPTION
!   Check if file exists
!   General purpose module.
!   Just a wrapper around the Fortran INQUIRE statement allowing the
!   test to be incorporated into a line of code as a logical variable.
!
    USE DRVBUF_DAT, ONLY: DRVBUF_ENABLED
  IMPLICIT NONE 
!
! ARGUMENTS
    CHARACTER(*), INTENT(IN) :: FILNAM ! File name to be tested
!
! EXECUTABLE CODE --------------------------------------------------------------
!
! When the buffer is active report that rfm.drv exists so downstream checks pass.
  IF ( DRVBUF_ENABLED .AND. TRIM ( FILNAM ) .EQ. 'rfm.drv' ) THEN
    LEXIST = .TRUE.
  ELSE
    INQUIRE ( FILE=FILNAM, EXIST=LEXIST ) 
  END IF
!
END FUNCTION LEXIST
END MODULE LEXIST_FNC
