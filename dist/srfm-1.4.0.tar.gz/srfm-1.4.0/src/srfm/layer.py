"""Defines the Layer class and all its subclasses.

Used to contain scattering information for a single layer.
- Name: layer
- Parent package: srfm
- Author: Antonin Knizek
- Contributors:
- Date: 26 Mar 2025
"""

from numbers import Real
from collections.abc import Mapping

import numpy as np
from . import optical_properties as op
from . import utilities as utils
import warnings
from . import size_distribution as sz
from multiprocessing import Process, Manager
import matplotlib.pyplot as plt
from .spectral_fields import SpectralField


NORMALIZED_MOMENT_TOLERANCE = 1e-5


class Layer:
    """Base superclass for an atmospheric layer."""

    def __init__(self, name=None, **parameters):
        """Initialize a named atmospheric layer.

        Args:
            name (str | None): Human-readable layer name.
            **parameters: Additional attributes assigned to the layer.
        """
        self.name = name
        for key, val in parameters.items():
            setattr(self, key, val)


class MieLayer(Layer):
    """Class that contains Mie scattering parameters, calculations and outputs.

    Is subclass of Layer.

    """

    def __init__(self, name=None, **parameters):
        """Initialize a layer used for Mie-scattering calculations.

        Args:
            name (str | None): Human-readable layer name.
            **parameters: Additional attributes assigned to the layer.
        """
        super().__init__(name)
        for key, val in parameters.items():
            setattr(self, key, val)

    def set_name(self, name):
        """Assign a name to the layer.

        Args:
            name (str): Layer name.

        """
        self.name = name

    def set_spc_lim(self, lo, hi):
        """Set spectral calculation grid lower and upper limits.

        Lo is the lower value and hi is the upper value, whatever the units. Units are
        then specified in set_spec_units, so this remains consistent with both
        wavenumbers and wavelengths.

        Args:
            lo (int, float): Lower wavenumber or wavelength.
            hi (int, float): Upper wavenumber or wavelength.

        """
        self.low_spc = lo
        self.upp_spc = hi

    def set_spec_units(self, units):
        """Set spectral calculation grid units.

        Args:
            units (str): Units. should be one of [\ :math:`\\mu`\ m, cm\ :sup:`-1`, nm].
                This is not enforced but currently the rest of this package is unable to
                handle any other options.

        """
        self.spec_units = units

    def set_res(self, res):
        """Set spectral calculation grid resolution.

        Args:
            res (int, float): Resolution of the spectral grid. Should be same units as
                values in set_spc_lim. This is not enforced, but is the only logically
                consistent option.

        """
        self.res = res

    def set_mass_loading(self, load):
        """Set particle mass loading.

        Args:
            load (int, float): Particle mass loading, units [g m\ :sup:`-2`].

        """
        self.mass_loading = load

    def set_n(self, n):
        """Set particle number concentration.

        Args:
            n (int, float): Particle number concentration, units [cm\ :sup:`-1`].

        """
        self.n = n

    def set_r(self, r):
        """Set mean particle radius.

        Args:
            r (int, float): Mean particle radius, units [\ :math:`\\mu`\ m]

        """
        self.r = r

    def set_s(self, s):
        """Set particle size distribution spread.

        Args:
            s (int, float): Particle size distribution spread.

        """
        self.s = s

    def set_rho(self, rho):
        """Set particle mean density.

        Args:
            rho (str, int, float): Particle mean density units [kg m\ :sup:`-3`\ ] or one
                of strings accepted by
                ``srfm.utilities.number_conc_from_mass_loading()``.

        """
        self.rho = rho

    def set_s_a_den(self, s_a_den):
        """Set surface area density of the particles.

        Args:
            s_a_den (int, float): Surface area density of the particles, units
                [\ :math:`\\mu`\ m\ :sup:`2` cm\ :sup:`-3`\ ].

        """
        self.s_a_den = s_a_den

    def set_v_den(self, v_den):
        """Set volume density of particles.

        Args:
            v_den (int, float): Particle volume density, units
                [\ :math:`\\mu`\ m\ :sup:`3` cm\ :sup:`-3`\ ].

        """
        self.v_den = v_den

    def set_dist_type(self, dist_type):
        """Set particle size distribution type.

        Args:
            dist_type (str): Particle size distribution type. Accepted values are
                *lognormal* and *normal*.

        """
        self.dist_type = dist_type

    def set_comp(self, comp):
        """Set particle composition type.

        Args:
            comp (str): One of accepted values by ``ARIA_module.get_ri_filepathname()``.

        """
        self.comp = comp

    def set_center_alt(self, center_alt):
        """Set average (center) particle layer altitude.

        Args:
            center_alt (int, float): Center particle layer altitude, units [km].

        """
        self.center_alt = center_alt

    def set_thick(self, thick):
        """Set layer thickness (vertical extent).

        Args:
            thick (int, float): Layer thickness (vertical extent), units [km].

        """
        self.thick = thick

    def set_alt_lim(self, alt_low, alt_upp):
        """Set lower and upper layer boundary (altitudes).

        Args:
            alt_low (int, float): Layer lower boundary altitude, units [km].
            alt_upp (int, float): Layer upper boundary altitude, units [km].

        """
        self.alt_upp = alt_upp
        self.alt_low = alt_low

    def set_radii(self, radii=200):
        """Set number of radii for size disitribution calculation.

        Args:
            radii (int): Number of radii in size distribution. Default is 200.

        """
        self.radii = radii

    def set_eta(self, eta=1e-6):
        """Set size distribution cut-off (eta value).

        Args:
            eta (int, float): Size distribution cut-off value. The size distribution is
                a function that technically spans the (-inf,+inf) size interval. The eta
                value is a value of the size distribution beyond whose corresponding
                size (radius) the distribution is truncated. Default is 1e-6.

        """
        self.eta = eta

    def set_phase_quad_N(self, phase_quad_N=181):
        """Set number of points for the scattering quadrature.

        The number of quadrature points is the number of scattering angles

        Args:
            phase_quad_N (int): Number of quadrature points. Default is 181.

        """
        self.phase_quad_N = phase_quad_N

    def set_phase_quad_type(self, phase_quad_type="L"):
        """Set quadrature type that will be used to calculate the phase fucntion.

        Args:
            phase_quad_type (str): Quadrature type for the phase function. Accetped
                values are values implemented in the ``srfm.quadrature`` module.
                Currently implemented (Apr 2025) are "L" (Lobatto quadrature rule),
                "G" (Gauss), "R" (Radau) and "T" (Trapezium). Default is L.

        """
        self.phase_quad_type = phase_quad_type

    def set_radii_quad_type(self, radii_quad_type="T"):
        """Set quadrature type for the calculation of the size distribution.

        Args:
            radii_quad_type (str): Quadrature type for the radii calculation function.
                Accetped values are values implemented in the ``srfm.quadrature``
                module. Currently implemented (Apr 2025) are "L" (Lobatto quadrature
                rule), "G" (Gauss), "R" (Radau) and "T" (Trapezium). Default is T.


        """
        self.radii_quad_type = radii_quad_type

    def set_leg_coeffs(self, leg_coeffs=True):
        """Toggle expansion of the phase fucntion into Legendre polynomials.

        Args:
            leg_coeffs (bool): If True, Legendre polynomial expansion of the phase
                function is calculated by ``srfm.optical_properties.ewp_hs()``. Default is
                True.

        """
        self.leg_coeffs = leg_coeffs

    def set_leg_coeffs_type(self, leg_coeffs_type="normalised"):
        """Set type of requested Legendre polynomial expansion coefficients.

        Args:
            leg_coeffs_type (str): Requested type of Legendre polynomial expansion
                coefficients. Accepted values are *regular* and *normalised*. Default
                is normalised.

        """
        self.leg_coeffs_type = leg_coeffs_type

    def set_multiproccess(self, multiprocess):
        """Toggle multiprocessing.

        Args:
            multiprocess (bool): if True, then ``srfm.optical_properties.ewp_hs()`` is
                calculated in a separate subprocess. The output type of ewp_hs changes!!

        """
        self.multiprocess = multiprocess

    def set_input_from_dict(self, inp_dict):
        """Set all necessary input_parameters from an input dictionary.

        Args:
            inp_dict (dict): Input dictionary with layer properties. It must
                contain the calculation inputs below plus either
                ``center_alt``/``thick`` or ``alt_low``/``alt_upp``:

                    - name
                    - low_spc
                    - upp_spc
                    - spec_units
                    - res
                    - mass_loading
                    - n
                    - r
                    - s
                    - rho
                    - s_a_den
                    - v_den
                    - dist_type
                    - comp
                    - radii
                    - eta
                    - phase_quad_N
                    - phase_quad_type
                    - radii_quad_type
                    - leg_coeffs
                    - leg_coeffs_type
                    - multiprocess

                For explanation of each of those parameters please refer to the
                respective function which set them explicitly (set_{parameter name}).

        """
        self.name = inp_dict["name"]
        self.low_spc = inp_dict["low_spc"]
        self.upp_spc = inp_dict["upp_spc"]
        self.spec_units = inp_dict["spec_units"]
        self.res = inp_dict["res"]
        self.mass_loading = inp_dict["mass_loading"]
        self.n = inp_dict["n"]
        self.r = inp_dict["r"]
        self.s = inp_dict["s"]
        self.rho = inp_dict["rho"]
        self.s_a_den = inp_dict["s_a_den"]
        self.v_den = inp_dict["v_den"]
        self.dist_type = inp_dict["dist_type"]
        self.comp = inp_dict["comp"]
        self.center_alt = inp_dict.get("center_alt")
        self.thick = inp_dict.get("thick")
        self.alt_upp = inp_dict.get("alt_upp")
        self.alt_low = inp_dict.get("alt_low")
        self.radii = inp_dict["radii"]
        self.eta = inp_dict["eta"]
        self.phase_quad_N = inp_dict["phase_quad_N"]
        self.phase_quad_type = inp_dict["phase_quad_type"]
        self.radii_quad_type = inp_dict["radii_quad_type"]
        self.leg_coeffs = inp_dict["leg_coeffs"]
        self.leg_coeffs_type = inp_dict["leg_coeffs_type"]
        self.multiprocess = inp_dict["multiprocess"]
        self.refractive_index = inp_dict.get("refractive_index")
        self.angle = inp_dict.get("angle")

    def test_complete_input_format(self):
        """Checks the input for correct format before running any calculation.

        Tests all input variables. Creates a boolean value called passmark, which is
        initially False and if the test is passed, is changed to True and returned.

        Returns:
            passmark (bool): If True, input has passed the format test.

        Raises:
            TypeError: Raised when test fails for each parameter separately.

        """
        passmark = False

        if not isinstance(self.name, str):
            raise TypeError("Name must be str.")

        if not isinstance(self.low_spc, (int, float)):
            raise TypeError("Low_spc must be int or float.")

        if not isinstance(self.upp_spc, (int, float)):
            raise TypeError("Upp_spc must be int or float.")

        if not isinstance(self.res, (int, float)):
            raise TypeError("res must be int or float.")

        if not isinstance(self.spec_units, str):
            raise TypeError("Spec_units must be str.")

        if not isinstance(self.mass_loading, (int, float, type(None))):
            raise TypeError("mass_loading must be int, float or type(None).")

        if not isinstance(self.n, (int, float)):
            raise TypeError("n must be int or float.")

        if not isinstance(self.r, (int, float)):
            raise TypeError("r must be int or float.")

        if not isinstance(self.s, (int, float)):
            raise TypeError("s must be int or float.")

        if not isinstance(self.rho, (int, float, str, type(None))):
            raise TypeError("rho must be int, float or type(None).")

        if not isinstance(self.s_a_den, (int, float, type(None))):
            raise TypeError("s_a_den must be int, float or type(None).")

        if not isinstance(self.v_den, (int, float, type(None))):
            raise TypeError("v_den must be int, float or type(None).")

        if not isinstance(self.dist_type, str):
            raise TypeError("Dist_type must be str.")

        if not isinstance(self.comp, str):
            raise TypeError("Comp must be str.")

        if not isinstance(self.center_alt, (int, float)):
            raise TypeError("Center_alt must be int or float.")

        if not isinstance(self.thick, (int, float)):
            raise TypeError("thick must be int or float.")

        if not isinstance(self.alt_upp, (int, float)):
            raise TypeError("Alt_upp must be int or float.")

        if not isinstance(self.alt_low, (int, float)):
            raise TypeError("Alt_low must be int or float.")

        if not isinstance(self.radii, int):
            raise TypeError("Radii must be int.")

        if not isinstance(self.eta, (int, float)):
            raise TypeError("Eta must be int or float.")

        if not isinstance(self.phase_quad_N, int):
            raise TypeError("Phase_quad_N must be int.")

        if not isinstance(self.phase_quad_type, str):
            raise TypeError("Phase_quad_type must be str.")

        if not isinstance(self.radii_quad_type, str):
            raise TypeError("radii_quad_type must be int or float.")

        if not isinstance(self.leg_coeffs, bool):
            raise TypeError("Leg_coeffs must be bool.")

        if not isinstance(self.leg_coeffs_type, str):
            raise TypeError("Leg_coeffs_type must be str.")

        if not isinstance(self.multiprocess, bool):
            raise TypeError("multiprocess must be bool.")

        passmark = True

        return passmark

    def test_input_values(self):
        """This function tests input values of the MieLayer class.

        The tests written in this function are added as bugs are encountered. The test
        is far from exhaustive and the user is encouraged to sanity check their values
        independently. Creates a boolean value called passmark, which is
        initially False and if the test is passed, is changed to True and returned.

        Returns:
            passmark (bool): If True, input has passed the format test.

        Raises:
            TypeError: Raised when test fails for each parameter separately.

        """

        passmark = False

        if self.low_spc < 0:
            raise ValueError("Attribute low_spc must be non-negative.")

        if self.upp_spc < 0:
            raise ValueError("Attribute upp_spc must be non-negative.")

        if hasattr(self, "mass_loading") and self.mass_loading < 0:
            raise ValueError("Attribute mass_loading must be non-negative.")

        if self.r < 0:
            raise ValueError("Particle mean radius (r) must be non-negative.")

        if self.s < 1:
            raise ValueError("Distribution spread must be >= 1.")

        if self.radii < 1:
            raise ValueError("Number of requested radii must be at least 1.")

        if self.phase_quad_N < 1:
            raise ValueError(
                """Number of scattering angles (phase function quadrature 
            points must be at least 1."""
            )

        if self.thick < 0.002:
            raise ValueError(
                """Thickness must be >= 0.002. This is because due to 
            various roundings in the code, RFM may insert two levels of equal altitude
            and then fail."""
            )

        passmark = True

        return passmark

    def validate_inputs(self):
        """Validate all Mie inputs before calculating optical properties.

        The method also resolves the configured vertical representation so every
        optical-layer object exposes finite lower and upper boundaries during the
        cross-layer geometry check.

        Returns:
            bool: ``True`` when every input is valid.

        Raises:
            TypeError: If an input has an unsupported type.
            ValueError: If an input is non-finite or outside its physical range.
            RuntimeError: If the vertical extent or particle loading is incomplete.
        """
        self.calc_layer_extent()
        if not isinstance(self.name, str) or not self.name:
            raise TypeError("Name must be a non-empty string.")
        for attribute_name in ("low_spc", "upp_spc", "res", "r", "s", "eta"):
            value = getattr(self, attribute_name, None)
            if (
                not isinstance(value, Real)
                or isinstance(value, (bool, np.bool_))
                or not np.isfinite(value)
            ):
                raise TypeError(f"{attribute_name} must be a finite real number.")
        if self.low_spc < 0 or self.upp_spc <= self.low_spc:
            raise ValueError("Mie spectral bounds must satisfy 0 <= low_spc < upp_spc.")
        if self.res <= 0:
            raise ValueError("Mie spectral resolution must be greater than zero.")
        if self.spec_units not in {"cm-1", "um", "nm"}:
            raise ValueError("Spec_units must be one of 'cm-1', 'um', or 'nm'.")
        if self.r < 0:
            raise ValueError("Particle mean radius (r) must be non-negative.")
        if self.s < 1:
            raise ValueError("Distribution spread must be greater than or equal to 1.")
        if not 0 < self.eta < 1:
            raise ValueError("Eta must satisfy 0 < eta < 1.")
        for attribute_name in ("radii", "phase_quad_N"):
            value = getattr(self, attribute_name, None)
            if type(value) is not int or value < 1:
                raise TypeError(f"{attribute_name} must be a positive integer.")
        for attribute_name in ("mass_loading", "n", "s_a_den", "v_den"):
            value = getattr(self, attribute_name, None)
            if value is not None and (
                not isinstance(value, Real)
                or isinstance(value, (bool, np.bool_))
                or not np.isfinite(value)
                or value < 0
            ):
                raise ValueError(f"{attribute_name} must be finite and non-negative.")
        if all(
            getattr(self, attribute_name, None) is None
            for attribute_name in ("mass_loading", "n", "s_a_den", "v_den")
        ):
            raise RuntimeError(
                "One of mass_loading, n, s_a_den, or v_den must be supplied."
            )
        density = getattr(self, "rho", None)
        if isinstance(density, Real) and not isinstance(density, (bool, np.bool_)):
            if not np.isfinite(density) or density <= 0:
                raise ValueError("rho must be finite and greater than zero.")
        elif not isinstance(density, str):
            raise TypeError("rho must be a finite real number or supported name.")
        for attribute_name in ("alt_low", "alt_upp", "center_alt", "thick"):
            value = getattr(self, attribute_name, None)
            if (
                not isinstance(value, Real)
                or isinstance(value, (bool, np.bool_))
                or not np.isfinite(value)
            ):
                raise TypeError(f"{attribute_name} must be a finite real number.")
        if self.alt_low >= self.alt_upp:
            raise ValueError("alt_low must be less than alt_upp.")
        if self.thick < 0.002:
            raise ValueError("Mie layer thickness must be at least 0.002 km.")
        return True

    def calculate_op(self, validate=True):
        """Used to calculate the optical properties for the MieLayer class.

        The function calls specialized functions to perform the actual calculations.

        The structure is the following:
            1. Checks the inputs consistency and format and calculates what is missing.
            2. Checks the inputs format (this is a little logically inconsistent
               because some checks must be performed in step one before missing
               properties are calculated).
            3. Calculate size distribution.
            4. Calculate spectral calculation grid.
            5. Calculate the optical properties, which are returned as class attributes.

        Raises:
            RuntimeError: Raised when input fails the format or input tests.

        """

        # Calculate layer vertical-extent properties and validate raw inputs before
        # deriving concentration or optical quantities.
        if validate:
            self.validate_inputs()
        self.nsv_or_ml()
        if self.test_complete_input_format():
            pass
        else:
            raise RuntimeError("Input did not pass format test.")

        if self.test_input_values():
            pass
        else:
            raise RuntimeError("Input did not pass value test.")

        self.calc_size_distribution()
        self.calc_grids()
        self.calc_optical_properties()

    @property
    def required_nmom(self):
        """Return the highest available normalized Legendre-moment order."""
        if not hasattr(self, "legendre_coefficient"):
            return 0
        return int(np.asarray(self.legendre_coefficient).shape[1] - 1)

    def column_optical_properties(self, wavenumber_cm_inverse, nmom=None):
        """Interpolate Mie column optical properties for one spectral block.

        Extinction coefficient is converted to complete layer optical depth inside
        this interface, keeping the runner independent of the particle source.

        Args:
            wavenumber_cm_inverse (array-like): Target grid in ``cm-1``.
            nmom (int | None): Optional maximum moment order. When supplied,
                calculated coefficients are padded with zeros through this order.

        Returns:
            dict[str, numpy.ndarray]: Column optical depth, single-scattering
            albedo, and normalized Legendre coefficients.
        """
        wavenumber = np.asarray(wavenumber_cm_inverse, dtype=float)
        wavelengths = 1.0e4 / wavenumber
        properties = self.interpolate_optical_properties(wavelengths)
        normalized_moments = properties["legendre_coefficient"]
        if nmom is not None:
            if type(nmom) is not int or nmom < self.required_nmom:
                raise ValueError("nmom must include every calculated Mie moment")
            padded_moments = np.zeros((wavenumber.size, nmom + 1), dtype=float)
            padded_moments[:, : normalized_moments.shape[1]] = normalized_moments
            normalized_moments = padded_moments
        return {
            "particle_optical_depth": (
                properties["beta_ext"] * 1.0e3 * (self.alt_upp - self.alt_low)
            ),
            "single_scattering_albedo": properties["ssalb"],
            "normalized_legendre_coefficients": normalized_moments,
        }

    def nsv_or_ml(self):
        """Check input for size distribution.

        Checks if either number concentration (n), surface area density (s_a_den) or
        volume density (v_den) are set or is mass loading (mass_loading) is set.
        The logic that s_a_den, v_den and n can be calculated from each other.
        mass_loading can be calculated from n and vice versa.

        Raises:
            RuntimeError: Raised if r and s are not set or if all values are missing.

        """
        if not (hasattr(self, "r") and self.r is not None):
            raise RuntimeError("Mean particle radius (r) must be set.")
        if not (hasattr(self, "s") and self.s is not None):
            raise RuntimeError("Size distribution spread (s) must be set.")

        if (
            (hasattr(self, "n") and self.n is not None)
            or (hasattr(self, "s_a_den") and self.s_a_den is not None)
            or (hasattr(self, "v_den") and self.v_den is not None)
        ):

            self.n_s_v()

            try:
                self.mass_loading = utils.mass_loading_from_number_conc(
                    self.n, self.thick, self.rho, self.s, self.dist_type, self.r
                )
            except AttributeError:
                warnings.warn(
                    """Could not calculate particle loading, because some of 
                thick, rho and r are not set, calculation 
                continues without it."""
                )
            except:
                warnings.warn(
                    """Could not calculate mass_loading, calculation 
                continues without it."""
                )
        elif hasattr(self, "mass_loading") and self.mass_loading is not None:
            self.n = utils.number_conc_from_mass_loading(
                self.mass_loading, self.rho, self.thick, self.s, self.dist_type, self.r
            )
            self.n_s_v()

        else:
            raise RuntimeError(
                """One of number concentration (n), surface area density (s_a_den), 
            volume density (v_den) or mass loading (mass_loading) must be set."""
            )

    def n_s_v(self):
        """Checks inputs for n, s or v.

        Checks if particle either particle number concentration (n), surface area
        density (s_a_den) or v_den are set and calculates the missing of the three.
        Requires meand particle radius (r) and distribution spread (s) to be set.
        If none of the three are set, but particle mass loading (mass_loading) is set
        instead, n will be calculated from particle loading.

        Raises:
            RuntimeError: Raised when calculation fails due to insensible values.
        """

        if hasattr(self, "n") and self.n is not None:
            self.s_a_den = (
                self.n * 4 * np.pi * self.r**2 * np.exp(2 * np.log(self.s) ** 2)
            )
            self.v_den = (
                self.n * 4 * np.pi * self.r**3 * np.exp(9 * np.log(self.s) ** 2 / 2) / 3
            )
        elif hasattr(self, "s_a_den") and self.s_a_den is not None:
            self.n = self.s_a_den / (
                4 * np.pi * self.r**2 * np.exp(2 * np.log(self.s) ** 2)
            )
            self.v_den = (
                self.n * 4 * np.pi * self.r**3 * np.exp(9 * np.log(self.s) ** 2 / 2) / 3
            )
        elif hasattr(self, "v_den") and self.v_den is not None:
            self.n = (
                3
                * self.v_den
                / (4 * np.pi * self.r**3 * np.exp(9 * np.log(self.s) ** 2 / 2))
            )
            self.s_a_den = (
                self.n * 4 * np.pi * self.r**2 * np.exp(2 * np.log(self.s) ** 2)
            )
        else:
            raise RuntimeError(
                """Something is wrong with number concentration, surface 
            area density and volume density. Are input values sensible?"""
            )

        return

    def calc_layer_extent(self):
        """This function attempts to calculate the layer vertical extent.

        If layer center altitude and vertical extent are given, the lower and upper
        boundary altitudes are calculated.
        Else if lower and upper boundaries are given, the center altitude and
        vertical extent are calculated.
        All variables are in units [km].

        Raises:
            RuntimeError: Raised when inputs are insufficient.
        """

        if (hasattr(self, "center_alt") and hasattr(self, "thick")) and (
            self.center_alt is not None and self.thick is not None
        ):
            if (hasattr(self, "alt_upp") and hasattr(self, "alt_low")) and (
                self.alt_upp is not None and self.alt_low is not None
            ):
                expected_upp, expected_low = utils.calc_layer_extent(
                    float(self.center_alt), float(self.thick)
                )
                if not (
                    np.isclose(self.alt_upp, expected_upp)
                    and np.isclose(self.alt_low, expected_low)
                ):
                    raise ValueError(
                        "Both layer center/thickness and boundary altitudes were "
                        "given, but do not match."
                    )

                return

            else:
                self.alt_upp, self.alt_low = utils.calc_layer_extent(
                    self.center_alt, self.thick
                )
                return

        elif (hasattr(self, "alt_upp") and hasattr(self, "alt_low")) and (
            self.alt_upp is not None and self.alt_low is not None
        ):
            self.center_alt, self.thick = utils.calc_layer_bounds(
                self.alt_upp, self.alt_low
            )
            return

        else:
            raise RuntimeError(
                """To calulate layer altitude characteristics either 
            upper and lower boundary altitude (alt_upp and alt_low) or layer center 
            altitude and vertical extent (center_alt and thick) must be given."""
            )
        return

    def calc_size_distribution(self):
        """Calls functions to calculate the size distribution."""
        self.size_distribution = sz.create_distribution(
            dist_type=self.dist_type,
            n=self.n,
            r=self.r,
            s=self.s,
            surface_area_density=self.s_a_den,
            volume_density=self.v_den,
        )
        return

    def calc_grids(self):
        """Calculates spectral grids for the calculation of optical properties.

        Calculates both wavelengths and wavenumbers.

        """
        self.wvnm, self.wvls = utils.calc_grids(
            lo=self.low_spc, hi=self.upp_spc, res=self.res, units=self.spec_units
        )
        return

    def calc_optical_properties(self):
        """Calculate optical layer properties.

        Calls ``srfm.optical_properties_ewp_hs()`` to calculate extinction coefficient,
        single scatter albedo, phase function and (optional) Legendre polynomial
        coefficients.

        Raises:
            ValueError: Raised when multiprocess isn't specified as attribute.

        """

        if not hasattr(self, "refractive_index"):
            self.refractive_index = None
        if not hasattr(self, "angle"):
            self.angle = None

        if self.multiprocess == False:
            self.op_dict = op.ewp_hs(
                wavelengths=self.wvls,
                composition=self.comp,
                distribution=self.size_distribution,
                refractive_index=self.refractive_index,
                angle=self.angle,
                legendre_coefficients_flag=self.leg_coeffs,
                legendre_coefficients_type=self.leg_coeffs_type,
                radii=self.radii,
                radii_quad_type=self.radii_quad_type,
                eta=self.eta,
                phase_quad_N=self.phase_quad_N,
                phase_quad_type=self.phase_quad_type,
                return_dict=None,
                multiprocess=False,
            )

        elif self.multiprocess == True:
            self.op_dictproxy = Manager().dict()
            self.op_process = Process(
                target=op.ewp_hs,
                kwargs={
                    "wavelengths": self.wvls,
                    "composition": self.comp,
                    "distribution": self.size_distribution,
                    "refractive_index": self.refractive_index,
                    "angle": self.angle,
                    "legendre_coefficients_flag": self.leg_coeffs,
                    "legendre_coefficients_type": self.leg_coeffs_type,
                    "radii": self.radii,
                    "eta": self.eta,
                    "phase_quad_N": self.phase_quad_N,
                    "phase_quad_type": self.phase_quad_type,
                    "radii_quad_type": self.radii_quad_type,
                    "return_dict": self.op_dictproxy,
                    "multiprocess": True,
                },
            )
            self.op_process.start()

        else:
            raise ValueError("multiprocess must be True or False.")
        return

    def add_op_calc_output(self):
        """Assigns results from optical properties calculation as class attributes.

        Takes results from optical properties calcualtion stored in a dictionary and
        assignes them as class attributes. This is a separate function so that when
        multiprocess is True, this step (adding results to class can be done after
        threads join in the main script in one command.
        This function deletes the original dictionary.

        """

        if hasattr(self, "op_process"):
            self.op_process.join()
            self.op_dict = {}
            self.op_dict.update(self.op_dictproxy)
            delattr(self, "op_dictproxy")

        if hasattr(self, "op_dict"):
            self.beta_ext = self.op_dict["beta_ext"]
            self.ssalb = self.op_dict["ssalb"]
            self.phase_function = self.op_dict["phase_function"]
            if "legendre_coefficient" in self.op_dict.keys():
                self.legendre_coefficient = self.op_dict["legendre_coefficient"]
            delattr(self, "op_dict")
        else:
            raise RuntimeError(
                """Optical properties (op_dict) not found. Were they 
            calcualted?"""
            )

    @utils.show_runtime
    def regrid(
        self,
        wvls,
        track_diff=False,
        diff_type="pct",
        regrid_phase_function=True,
        retain_original=None,
    ):
        """Linearly interpolate selected optical properties to a new grid.

        The compatibility defaults preserve the historical phase-function and
        ``*_old`` attributes. Memory-sensitive callers can omit the full phase
        function and original arrays explicitly.

        Args:
            wvls (array-like): New wavelength grid in micrometres.
            track_diff (bool): Calculate interpolation differences when true.
            diff_type (str): Difference representation, ``"pct"`` or ``"abs"``.
            regrid_phase_function (bool): Interpolate the phase function when true;
                otherwise remove it after any requested original retention.
            retain_original (bool | None): Retain coarse arrays as ``*_old``. ``None``
                preserves historical behavior; difference tracking always retains them.

        Returns:
            None: Selected layer properties are replaced with interpolated arrays.

        Raises:
            ValueError: If either wavelength grid is not monotonic.
        """
        if retain_original is None:
            retain_original = True
        retain_original = bool(retain_original or track_diff)
        original_names = (
            "wvls",
            "beta_ext",
            "ssalb",
            "phase_function",
            "legendre_coefficient",
        )
        if retain_original:
            for attribute_name in original_names:
                if hasattr(self, attribute_name):
                    setattr(self, f"{attribute_name}_old", getattr(self, attribute_name))
        else:
            for attribute_name in original_names:
                old_name = f"{attribute_name}_old"
                if hasattr(self, old_name):
                    delattr(self, old_name)

        interpolated = self.interpolate_optical_properties(
            wvls, include_phase_function=regrid_phase_function or track_diff
        )
        self.wvls = interpolated.pop("wavelengths")
        self.beta_ext = interpolated["beta_ext"]
        self.ssalb = interpolated["ssalb"]
        if "legendre_coefficient" in interpolated:
            self.legendre_coefficient = interpolated["legendre_coefficient"]
        if regrid_phase_function or track_diff:
            self.phase_function = interpolated["phase_function"]
        elif hasattr(self, "phase_function"):
            delattr(self, "phase_function")

        if track_diff:
            self.track_regrid_diff(diff_type=diff_type)

    def interpolate_optical_properties(
        self, wvls, include_phase_function=False, include_legendre=True
    ):
        """Interpolate optical properties without modifying the coarse layer data.

        This method is intended for bounded spectral blocks. It matches
        :func:`numpy.interp` endpoint behavior and restores the requested grid order.

        Args:
            wvls (array-like): Target wavelengths in micrometres.
            include_phase_function (bool): Include the full phase-function matrix.
            include_legendre (bool): Include Legendre coefficients when available.

        Returns:
            dict: Interpolated wavelengths, extinction, single-scattering albedo,
                optional Legendre coefficients, and optional phase function.

        Raises:
            ValueError: If the source or target wavelength grid is not monotonic.
        """
        target = np.asarray(wvls, dtype=float)
        # A final spectral block may legitimately contain one point. There is no
        # ordering ambiguity in that case, and numpy.interp handles it directly.
        target_order = 1 if target.size < 2 else utils.monotonic(target)
        source = np.asarray(self.wvls, dtype=float)
        source_order = utils.monotonic(source)
        if target_order == 0:
            raise ValueError("Wvls is not monotonic.")
        if source_order == 0:
            raise ValueError("Layer wavelengths are not monotonic.")

        interpolation_target = target[::-1] if target_order == 2 else target
        interpolation_source = source[::-1] if source_order == 2 else source

        def interpolate(values):
            """Interpolate one property array onto the requested wavelength grid."""
            values = np.asarray(values)
            ordered_values = values[::-1] if source_order == 2 else values
            if ordered_values.ndim == 1:
                output = np.interp(
                    interpolation_target, interpolation_source, ordered_values
                )
            else:
                output = np.empty(
                    (interpolation_target.size, ordered_values.shape[1]), dtype=float
                )
                for column_index in range(ordered_values.shape[1]):
                    output[:, column_index] = np.interp(
                        interpolation_target,
                        interpolation_source,
                        ordered_values[:, column_index],
                    )
            return output[::-1] if target_order == 2 else output

        result = {
            "wavelengths": target.copy(),
            "beta_ext": interpolate(self.beta_ext),
            "ssalb": interpolate(self.ssalb),
        }
        if include_legendre and hasattr(self, "legendre_coefficient"):
            result["legendre_coefficient"] = interpolate(
                self.legendre_coefficient
            )
        if include_phase_function:
            if not hasattr(self, "phase_function"):
                raise ValueError("The phase function was deliberately not retained.")
            result["phase_function"] = interpolate(self.phase_function)
        return result

    def discard_phase_function(self):
        """Release the coarse phase function after its moments have been calculated.

        Returns:
            None: The layer no longer has a ``phase_function`` attribute.
        """
        if hasattr(self, "phase_function"):
            delattr(self, "phase_function")

    def track_regrid_diff(self, diff_type="pct"):
        """Calculates the difference before and after interpolation.

        Called by optical_properties.regrid().

        Args:
            diff_type (str): "pct" (differences in percent from the old value) or
                "abs" (absolute difference)

        Raises:
            ValueError: Raised when diff_type is invalid.

        """
        # check if legendre coefficients present
        lc_flag = hasattr(self, "legendre_coefficient")

        diff_dict = {}
        diff_dict["wavelengths"] = self.wvls

        temp_dict = {}
        temp_dict["wavelengths"] = self.wvls
        temp_dict["beta_ext"] = []
        temp_dict["ssalb"] = []
        temp_dict["phase_function"] = []
        if lc_flag == True:
            temp_dict["legendre_coefficient"] = []

        for i in self.wvls:
            x = np.argmin(np.abs(self.wvls_old - np.full(self.wvls_old.size, i)))
            temp_dict["beta_ext"].append(self.beta_ext_old[x])
            temp_dict["ssalb"].append(self.ssalb_old[x])
            temp_dict["phase_function"].append(self.phase_function_old[x])
            if lc_flag == True:
                temp_dict["legendre_coefficient"].append(
                    self.legendre_coefficient_old[x]
                )

        for key in temp_dict.keys():
            if key == "wavelengths":
                pass
            else:
                temp_dict[key] = np.asarray(temp_dict[key])

        self.beta_ext_diff = np.abs(temp_dict["beta_ext"] - self.beta_ext)
        self.ssalb_diff = np.abs(temp_dict["ssalb"] - self.ssalb)
        self.phase_function_diff = np.abs(
            temp_dict["phase_function"] - self.phase_function
        )
        if lc_flag == True:
            self.legendre_coefficient_diff = np.abs(
                temp_dict["legendre_coefficient"] - self.legendre_coefficient
            )

        if diff_type == "abs":
            return

        elif diff_type == "pct":
            self.beta_ext_diff = (
                np.nan_to_num(np.divide(self.beta_ext_diff, temp_dict["beta_ext"]))
                * 100
            )
            self.ssalb_diff = (
                np.nan_to_num(np.divide(self.ssalb_diff, temp_dict["ssalb"])) * 100
            )
            self.phase_function_diff = (
                np.nan_to_num(
                    np.divide(self.phase_function_diff, temp_dict["phase_function"])
                )
                * 100
            )
            if lc_flag == True:
                self.legendre_coefficient_diff = (
                    np.nan_to_num(
                        np.divide(
                            self.legendre_coefficient_diff,
                            temp_dict["legendre_coefficient"],
                        )
                    )
                    * 100
                )
            return
        else:
            raise ValueError("diff_type must be pct or abs.")

        return

    def plot_diff(self, **kwargs):
        """Plots difference in calcualted optical properties.

        Instance must have differences in optical properties calculated and stored
        as _diff attributes. For further information see
        ``srfm.layer.track_regrid_diff()``.

        Returns:
            fig (obj): fig object
        """
        fig = plt.figure(figsize=(11.7, 8.3))

        plt.subplot(3, 1, 1)
        plt.plot(self.wvls, self.beta_ext_diff, label="beta_ext")
        plt.xlabel("wavelength (um)", fontsize="12")
        plt.ylabel(r"$\Delta \beta ^{ext} (\lambda)$ (%)", fontsize="12")
        # plt.yscale("log")
        plt.title("Extinction coefficient", fontsize="15")

        plt.subplot(3, 1, 2)
        plt.plot(self.wvls, self.ssalb_diff, label="ssalb")
        plt.xlabel("wavelength (um)", fontsize="12")
        plt.ylabel(r"$\Delta \omega (\lambda)$ (%)", fontsize="12")
        # plt.yscale("log")
        plt.title("Single scattering albedo", fontsize="15")

        plt.subplot(3, 1, 3)
        [
            plt.plot(
                self.wvls,
                self.phase_function_diff[:, i],
                label=f"phase function, {i} deg",
            )
            for i in range(self.phase_function_diff.shape[1])
        ]
        plt.xlabel("wavelength (um)", fontsize="12")
        plt.ylabel(r"$\Delta p(\mu, \lambda)$ (%)", fontsize="12")
        # plt.yscale("log")
        # plt.legend()
        plt.title("Phase function - each line represents one angle", fontsize="15")

        #        plt.subplot(4, 1, 4)
        #        [
        #            plt.plot(
        #                diff_dict["wavelengths"],
        #                diff_dict["legendre_coefficient"][:, i],
        #                label=f"legendre coefficient no. {i}",
        #            )
        #            for i in range(diff_dict["legendre_coefficient"].shape[1])
        #        ]
        #        plt.xlabel("wavelength (um)")
        #        plt.ylabel("legendre coefficients")
        #        plt.yscale("log")
        #        # plt.legend()

        plt.suptitle(
            "Difference in optical properties arising from interpolation", fontsize="18"
        )
        plt.tight_layout()
        return fig

    def calc_tau(self):
        """Calculates optical depth from beta_ext and layer vertical extent.

        Both beta_ext and layer boundary altitudes must be specified in the object
        instance.
        """
        self.tau = self.beta_ext * 1e3 * (self.alt_upp - self.alt_low)
        return


class PrescribedOpticalLayer(Layer):
    """Layer whose column particle optical properties are supplied by the user.

    Optical depth may be tabulated or follow an Angstrom law. Single-scattering
    albedo may be scalar or spectral. Phase data may be analytic
    Henyey-Greenstein asymmetry or tabulated normalized Legendre moments.
    """

    def set_input_from_dict(self, inp_dict):
        """Set prescribed-layer inputs from their public mapping.

        Args:
            inp_dict (Mapping): Layer name, bounds, optical depth, albedo, and
                optional phase-function specification.
        """
        self.name = inp_dict["name"]
        self.alt_low = inp_dict["alt_low"]
        self.alt_upp = inp_dict["alt_upp"]
        self.optical_depth_input = inp_dict["optical_depth"]
        self.single_scattering_albedo_input = inp_dict["ssalb"]
        self.phase_function_input = inp_dict.get("phase_function")

    @staticmethod
    def _finite_scalar(value, field_path, minimum=None, maximum=None):
        """Return one validated finite real scalar."""
        if (
            not isinstance(value, Real)
            or isinstance(value, (bool, np.bool_))
            or not np.isfinite(value)
        ):
            raise ValueError(f"{field_path} must be a finite real number")
        scalar = float(value)
        if minimum is not None and scalar < minimum:
            raise ValueError(f"{field_path} must be greater than or equal to {minimum:g}")
        if maximum is not None and scalar > maximum:
            raise ValueError(f"{field_path} must be less than or equal to {maximum:g}")
        return scalar

    def validate_inputs(
        self,
        computational_wavenumber_cm_inverse,
        *,
        scattering_block_size=10000,
    ):
        """Validate and prepare every prescribed optical input.

        Validation processes the computational grid in bounded blocks when phase
        requirements depend on interpolated scattering optical depth. No RFM,
        Mie, or DISORT calculation is invoked.

        Args:
            computational_wavenumber_cm_inverse (array-like): Complete model grid
                in ``cm-1``.
            scattering_block_size (int): Maximum number of target points handled
                together while validating coupled spectral quantities.

        Returns:
            bool: ``True`` when all inputs are valid.

        Raises:
            TypeError: If a required mapping has the wrong type.
            ValueError: If geometry, spectra, or phase normalization are invalid.
        """
        path = f"prescribed_lyrs_inputs.{self.name}"
        if not isinstance(self.name, str) or not self.name:
            raise TypeError("Prescribed layer name must be a non-empty string")
        self.alt_low = self._finite_scalar(self.alt_low, f"{path}.alt_low")
        self.alt_upp = self._finite_scalar(self.alt_upp, f"{path}.alt_upp")
        if self.alt_low >= self.alt_upp:
            raise ValueError(f"{path}.alt_low must be less than alt_upp")
        self.thick = self.alt_upp - self.alt_low
        self.center_alt = self.alt_low + self.thick / 2.0
        if type(scattering_block_size) is not int or scattering_block_size <= 0:
            raise ValueError("scattering_block_size must be a positive integer")
        computational_grid = np.asarray(
            computational_wavenumber_cm_inverse, dtype=float
        )
        if (
            computational_grid.ndim != 1
            or computational_grid.size == 0
            or not np.all(np.isfinite(computational_grid))
            or np.any(computational_grid <= 0)
        ):
            raise ValueError("computational wavenumber grid must be finite and positive")

        optical_depth = self.optical_depth_input
        if not isinstance(optical_depth, Mapping):
            raise TypeError(f"{path}.optical_depth must be a mapping")
        optical_depth_type = optical_depth.get("type")
        self.optical_depth_type = optical_depth_type
        self.optical_depth_field = None
        if optical_depth_type == "angstrom":
            self.reference_optical_depth = self._finite_scalar(
                optical_depth.get("reference_value"),
                f"{path}.optical_depth.reference_value",
                minimum=0,
            )
            self.reference_wavelength_um = self._finite_scalar(
                optical_depth.get("reference_wavelength_um"),
                f"{path}.optical_depth.reference_wavelength_um",
                minimum=np.nextafter(0.0, 1.0),
            )
            self.angstrom_exponent = self._finite_scalar(
                optical_depth.get("angstrom_exponent"),
                f"{path}.optical_depth.angstrom_exponent",
            )
        elif optical_depth_type == "tabulated":
            self.optical_depth_field = SpectralField.from_specification(
                optical_depth,
                f"{path}.optical_depth",
                minimum=0,
            )
            self.optical_depth_field.validate_coverage(computational_grid)
        else:
            raise ValueError(
                f"{path}.optical_depth.type must be 'angstrom' or 'tabulated'"
            )

        single_scattering_albedo = self.single_scattering_albedo_input
        self.single_scattering_albedo_field = None
        if isinstance(single_scattering_albedo, Real) and not isinstance(
            single_scattering_albedo, (bool, np.bool_)
        ):
            self.single_scattering_albedo_scalar = self._finite_scalar(
                single_scattering_albedo,
                f"{path}.ssalb",
                minimum=0,
                maximum=1,
            )
        elif isinstance(single_scattering_albedo, Mapping):
            self.single_scattering_albedo_scalar = None
            self.single_scattering_albedo_field = SpectralField.from_specification(
                single_scattering_albedo,
                f"{path}.ssalb",
                minimum=0,
                maximum=1,
            )
            self.single_scattering_albedo_field.validate_coverage(computational_grid)
        else:
            raise TypeError(
                f"{path}.ssalb must be a finite scalar or a spectral-field mapping; "
                "bare arrays have no interpolation coordinate"
            )

        phase_function = self.phase_function_input
        self.phase_function_type = None
        self.asymmetry_scalar = None
        self.asymmetry_field = None
        self.moment_field = None
        if phase_function is not None:
            if not isinstance(phase_function, Mapping):
                raise TypeError(f"{path}.phase_function must be a mapping or None")
            self.phase_function_type = phase_function.get("type")
            if self.phase_function_type == "henyey_greenstein":
                asymmetry = phase_function.get("asymmetry")
                if isinstance(asymmetry, Real) and not isinstance(
                    asymmetry, (bool, np.bool_)
                ):
                    self.asymmetry_scalar = self._finite_scalar(
                        asymmetry,
                        f"{path}.phase_function.asymmetry",
                        minimum=-1,
                        maximum=1,
                    )
                elif isinstance(asymmetry, Mapping):
                    self.asymmetry_field = SpectralField.from_specification(
                        asymmetry,
                        f"{path}.phase_function.asymmetry",
                        minimum=-1,
                        maximum=1,
                    )
                    self.asymmetry_field.validate_coverage(computational_grid)
                else:
                    raise TypeError(
                        f"{path}.phase_function.asymmetry must be a scalar or "
                        "spectral-field mapping"
                    )
            elif self.phase_function_type == "legendre_moments":
                if phase_function.get("convention") != "normalised":
                    raise ValueError(
                        f"{path}.phase_function.convention must be 'normalised'"
                    )
                self.moment_field = SpectralField.from_specification(
                    phase_function,
                    f"{path}.phase_function",
                    matrix_values=True,
                )
                self.moment_field.validate_coverage(computational_grid)
            else:
                raise ValueError(
                    f"{path}.phase_function.type must be 'henyey_greenstein' "
                    "or 'legendre_moments'"
                )

        phase_required = False
        for start in range(0, computational_grid.size, scattering_block_size):
            stop = min(start + scattering_block_size, computational_grid.size)
            block = computational_grid[start:stop]
            particle_optical_depth = self._interpolate_optical_depth(block)
            single_scattering_albedo = self._interpolate_single_scattering_albedo(block)
            if not np.all(np.isfinite(particle_optical_depth)) or np.any(
                particle_optical_depth < 0
            ):
                raise ValueError(
                    f"{path}.optical_depth must be finite and non-negative "
                    "throughout the computational grid"
                )
            if not np.all(np.isfinite(single_scattering_albedo)) or np.any(
                (single_scattering_albedo < 0) | (single_scattering_albedo > 1)
            ):
                raise ValueError(
                    f"{path}.ssalb must be finite and in [0, 1] throughout "
                    "the computational grid"
                )
            scattering = particle_optical_depth * single_scattering_albedo > 0
            if np.any(scattering):
                phase_required = True
                if self.moment_field is not None:
                    zeroth_moment = self.moment_field.interpolate(block)[:, 0]
                    if np.any(
                        np.abs(zeroth_moment[scattering] - 1.0)
                        > NORMALIZED_MOMENT_TOLERANCE
                    ):
                        raise ValueError(
                            f"{path}.phase_function.values: beta_0 must equal 1 "
                            f"within {NORMALIZED_MOMENT_TOLERANCE:g} wherever "
                            "particle scattering optical depth is positive"
                        )
        if phase_required and self.phase_function_type is None:
            raise ValueError(
                f"{path}.phase_function is required where optical_depth * ssalb is positive"
            )
        self._validated = True
        return True

    @property
    def required_nmom(self):
        """Return the highest explicitly supplied Legendre-moment order."""
        return 0 if self.moment_field is None else self.moment_field.component_count - 1

    def _interpolate_optical_depth(self, wavenumber_cm_inverse):
        """Evaluate prescribed column optical depth on one target block."""
        wavenumber = np.asarray(wavenumber_cm_inverse, dtype=float)
        if self.optical_depth_type == "angstrom":
            wavelength_um = 1.0e4 / wavenumber
            return self.reference_optical_depth * (
                wavelength_um / self.reference_wavelength_um
            ) ** (-self.angstrom_exponent)
        return self.optical_depth_field.interpolate(wavenumber)

    def _interpolate_single_scattering_albedo(self, wavenumber_cm_inverse):
        """Evaluate particle single-scattering albedo on one target block."""
        wavenumber = np.asarray(wavenumber_cm_inverse, dtype=float)
        if self.single_scattering_albedo_field is None:
            return np.full(wavenumber.shape, self.single_scattering_albedo_scalar)
        return self.single_scattering_albedo_field.interpolate(wavenumber)

    def column_optical_properties(self, wavenumber_cm_inverse, nmom=None):
        """Return prescribed column optical properties for one spectral block.

        Args:
            wavenumber_cm_inverse (array-like): Target wavenumbers in ``cm-1``.
            nmom (int | None): Highest requested Legendre order. Defaults to the
                highest explicitly supplied order or zero.

        Returns:
            dict[str, numpy.ndarray]: Column optical depth, single-scattering
            albedo, and normalized Legendre coefficients.

        Raises:
            RuntimeError: If :meth:`validate_inputs` has not been called.
            ValueError: If ``nmom`` is negative or smaller than tabulated data.
        """
        if not getattr(self, "_validated", False):
            raise RuntimeError("validate_inputs must be called before optical interpolation")
        if nmom is None:
            nmom = self.required_nmom
        if type(nmom) is not int or nmom < self.required_nmom:
            raise ValueError("nmom must include every supplied Legendre moment")
        wavenumber = np.asarray(wavenumber_cm_inverse, dtype=float)
        particle_optical_depth = self._interpolate_optical_depth(wavenumber)
        single_scattering_albedo = self._interpolate_single_scattering_albedo(wavenumber)
        if self.phase_function_type is None:
            moments = np.zeros((wavenumber.size, nmom + 1), dtype=float)
            moments[:, 0] = 1.0
        elif self.phase_function_type == "henyey_greenstein":
            if self.asymmetry_field is None:
                asymmetry = np.full(wavenumber.shape, self.asymmetry_scalar)
            else:
                asymmetry = self.asymmetry_field.interpolate(wavenumber)
            moments = asymmetry[:, np.newaxis] ** np.arange(nmom + 1)[np.newaxis, :]
        else:
            supplied = self.moment_field.interpolate(wavenumber)
            moments = np.zeros((wavenumber.size, nmom + 1), dtype=float)
            moments[:, : supplied.shape[1]] = supplied
        return {
            "particle_optical_depth": particle_optical_depth,
            "single_scattering_albedo": single_scattering_albedo,
            "normalized_legendre_coefficients": moments,
        }

    def source_metadata(self):
        """Return compact prescribed-input provenance without numerical arrays."""
        metadata = {
            "name": self.name,
            "layer_type": "prescribed",
            "alt_low": self.alt_low,
            "alt_upp": self.alt_upp,
        }
        if self.optical_depth_type == "angstrom":
            metadata["optical_depth"] = {
                "type": "angstrom",
                "reference_value": self.reference_optical_depth,
                "reference_wavelength_um": self.reference_wavelength_um,
                "angstrom_exponent": self.angstrom_exponent,
            }
        else:
            metadata["optical_depth"] = {
                "type": "tabulated",
                **self.optical_depth_field.provenance(),
            }
        if self.single_scattering_albedo_field is None:
            metadata["ssalb"] = self.single_scattering_albedo_scalar
        else:
            metadata["ssalb"] = self.single_scattering_albedo_field.provenance()
        if self.phase_function_type == "henyey_greenstein":
            metadata["phase_function"] = {
                "type": "henyey_greenstein",
                "asymmetry": (
                    self.asymmetry_scalar
                    if self.asymmetry_field is None
                    else self.asymmetry_field.provenance()
                ),
            }
        elif self.phase_function_type == "legendre_moments":
            metadata["phase_function"] = {
                "type": "legendre_moments",
                "convention": "normalised",
                **self.moment_field.provenance(),
            }
        else:
            metadata["phase_function"] = None
        return metadata


class GreyBodyCloud(Layer):
    """Class that represents a grey body cloud.

    Is subclass of Layer.
    The rationale for this class is to emulate the simplest possible case where a cloud
    is represented as a greybody emitter. No scattering is involved.

    Unless changed, emissivity is 1 by default.

    Todo:
        The emissivity is a stub, the attribute isn't implemented anywhere. For the time
        being then, the GreyBodyCloud is effectively a black body emitter.

    """

    def __init__(self, name=None, emis=1, **parameters):
        """Initialize a grey-body cloud layer.

        Args:
            name (str | None): Human-readable layer name.
            emis (int, float): Cloud emissivity.
            **parameters: Additional attributes assigned to the layer.
        """
        super().__init__(name, **parameters)
        self.emis = emis

    def set_name(self, name):
        """Assign a name to the layer.

        Args:
            name (str): Layer name.

        """
        self.name = name

    def set_spc_lim(self, lo, hi):
        """Set spectral grid lower and upper limits.

        Lo is the lower value and hi is the upper value, whatever the units. Units are
        then specified in set_spec_units, so this remains consistent with both
        wavenumbers and wavelengths.

        Args:
            lo (int, float): Lower wavenumber or wavelength.
            hi (int, float): Upper wavenumber or wavelength.

        """
        self.low_spc = lo
        self.upp_spc = hi

    def set_spec_units(self, units):
        """Set spectral calculation grid units.

        Args:
            units (str): Units; one of micrometres (``um``), inverse centimetres
                (``cm-1``), or nanometres (``nm``).
                This is not enforced but currently the rest of this package is unable to
                handle any other options.

        """
        self.spec_units = units

    def set_res(self, res):
        """Set spectral calculation grid resolution.

        Args:
            res (int, float): Resolution of the spectral grid. Should be same units as
                values in set_spc_lim. This is not enforced, but is the only logically
                consistent option.

        """
        self.res = res

    def set_center_alt(self, center_alt):
        """Set average (center) particle layer altitude.

        Args:
            center_alt (int, float): Center particle layer altitude, units [km].

        """
        self.center_alt = center_alt

    def set_thick(self, thick):
        """Set layer thickness (vertical extent).

        Args:
            thick (int, float): Layer thickness (vertical extent), units [km].

        """
        self.thick = thick

    def set_alt_lim(self, alt_low, alt_upp):
        """Set lower and upper layer boundary (altitudes).

        Args:
            alt_low (int, float): Layer lower boundary altitude, units [km].
            alt_upp (int, float): Layer upper boundary altitude, units [km].

        """
        self.alt_upp = alt_upp
        self.alt_low = alt_low

    def set_emis(self, e):
        """Set emissivity of the clouds.

        Args:
            e (int, float): Grey body emissivity.

        """
        self.emis = e

    def set_tau(self, tau):
        """Set input layer optical depth.

        Args:
            tau (int, float): Layer optical depth. The optical depth is uniform across
                all wavelengths (since this class represents a grey-body cloud).

        """

        self.inp_tau = tau

    def set_input_from_dict(self, inp_dict):
        """Set all necessary input parameters from an input dictionary.

        Args:
            inp_dict (dict): Input dictionary with layer properties. It must
                contain the calculation inputs below plus either
                ``center_alt``/``thick`` or ``alt_low``/``alt_upp``:

                    - name
                    - low_spc
                    - upp_spc
                    - spec_units
                    - res
                    - emis
                    - inp_tau

                For explanation of each of those parameters please refer to the
                respective function which sets them explicitly (set_{parameter name}).

        """
        self.name = inp_dict["name"]
        self.low_spc = inp_dict["low_spc"]
        self.upp_spc = inp_dict["upp_spc"]
        self.spec_units = inp_dict["spec_units"]
        self.res = inp_dict["res"]
        self.center_alt = inp_dict.get("center_alt")
        self.thick = inp_dict.get("thick")
        self.alt_upp = inp_dict.get("alt_upp")
        self.alt_low = inp_dict.get("alt_low")
        self.emis = inp_dict["emis"]
        self.inp_tau = inp_dict["inp_tau"]

    def test_complete_input_format(self):
        """Checks the input for correct format before running any calculation.

        Tests all input variables. Creates a boolean value called passmark, which is
        initially False and if the test is passed, is changed to True and returned.

        Returns:
            passmark (bool): If True, input has passed the format test.

        Raises:
            TypeError: Raised when an input has an unsupported type.

        """
        if not isinstance(self.name, str):
            raise TypeError("Name must be str.")

        if not isinstance(self.spec_units, str):
            raise TypeError("Spec_units must be str.")

        numeric_attributes = (
            "low_spc",
            "upp_spc",
            "res",
            "center_alt",
            "thick",
            "alt_upp",
            "alt_low",
            "emis",
            "inp_tau",
        )
        for attribute_name in numeric_attributes:
            value = getattr(self, attribute_name)
            if (
                not isinstance(value, Real)
                or isinstance(value, (bool, np.bool_))
                or not np.isfinite(value)
            ):
                raise TypeError(f"{attribute_name} must be a finite real number.")

        return True

    def test_input_values(self):
        """This function tests input values of the GreyBodyCloud class.

        The tests written in this function are added as bugs are encountered. The test
        is far from exhaustive and the user is encouraged to sanity check their values
        independently. Creates a boolean value called passmark, which is
        initially False and if the test is passed, is changed to True and returned.

        Returns:
            passmark (bool): If True, input has passed the format test.

        Raises:
            ValueError: Raised when a value is outside its supported range.

        """

        passmark = False

        if self.low_spc < 0:
            raise ValueError("Attribute low_spc must be non-negative.")

        if self.upp_spc < 0:
            raise ValueError("Attribute upp_spc must be non-negative.")

        if self.low_spc >= self.upp_spc:
            raise ValueError("Attribute low_spc must be less than upp_spc.")

        if self.res <= 0:
            raise ValueError("Attribute res must be greater than zero.")

        if self.spec_units not in {"cm-1", "um", "nm"}:
            raise ValueError("Spec_units must be one of 'cm-1', 'um', or 'nm'.")

        if self.emis < 0 or self.emis > 1:
            raise ValueError("Emissivity must be between 0 and 1.")

        if self.inp_tau < 0:
            raise ValueError("Optical depth must be non-negative.")

        if self.thick < 0.002:
            raise ValueError(
                """Thickness must be >= 0.002. This is because due to 
            various roundings in the code, RFM may insert two levels of equal altitude
            and then fail."""
            )

        passmark = True

        return passmark

    def validate_inputs(self):
        """Validate all grey-body inputs before calculating optical depth.

        Returns:
            bool: ``True`` when every input is valid.

        Raises:
            TypeError: If an input has an unsupported type.
            ValueError: If an input is non-finite or outside its supported range.
            RuntimeError: If vertical geometry is incomplete.
        """
        self.calc_layer_extent()
        if not isinstance(self.name, str) or not self.name:
            raise TypeError("Name must be a non-empty string.")
        if not isinstance(self.spec_units, str):
            raise TypeError("Spec_units must be str.")
        numeric_attributes = (
            "low_spc",
            "upp_spc",
            "res",
            "center_alt",
            "thick",
            "alt_upp",
            "alt_low",
            "emis",
            "inp_tau",
        )
        for attribute_name in numeric_attributes:
            value = getattr(self, attribute_name, None)
            if (
                not isinstance(value, Real)
                or isinstance(value, (bool, np.bool_))
                or not np.isfinite(value)
            ):
                raise TypeError(f"{attribute_name} must be a finite real number.")
        if self.low_spc < 0 or self.low_spc >= self.upp_spc:
            raise ValueError("Grey-body bounds must satisfy 0 <= low_spc < upp_spc.")
        if self.res <= 0:
            raise ValueError("Grey-body spectral resolution must be greater than zero.")
        if self.spec_units not in {"cm-1", "um", "nm"}:
            raise ValueError("Spec_units must be one of 'cm-1', 'um', or 'nm'.")
        if not 0 <= self.emis <= 1:
            raise ValueError("Emissivity must be between 0 and 1.")
        if self.inp_tau < 0:
            raise ValueError("Optical depth must be non-negative.")
        if self.alt_low >= self.alt_upp:
            raise ValueError("alt_low must be less than alt_upp.")
        if self.thick < 0.002:
            raise ValueError("Grey-body layer thickness must be at least 0.002 km.")
        return True

    def calculate_op(self, validate=True):
        """Used to calculate the optical properties for the GreyBodyCloud class.

        The function calls specialized functions to perform the actual calculations.

        The structure is the following:
            1. Checks the inputs consistency and format and calculates what is missing.
            2. If emissivity not set, defaults to 1.
            3. Checks the inputs format (this is a little logically inconsistent
               because some checks must be performed in step one before missing
               properties are calculated).
            4. Calculate spectral grid.
            5. Calculate the optical properties, which are returned as class attributes.

        Raises:
            RuntimeError: Raised when input fails the format or input tests.

        """

        # Resolve and validate geometry before calculating any optical quantities.
        if validate:
            self.validate_inputs()

        if self.test_complete_input_format():
            pass
        else:
            raise RuntimeError("Input did not pass format test.")

        if self.test_input_values():
            pass
        else:
            raise RuntimeError("Input did not pass value test.")

        self.calc_grids()
        self.calc_optical_properties()

    def calc_layer_extent(self):
        """This function attempts to calculate the layer vertical extent.

        If layer center altitude and vertical extent are given, the lower and upper
        boundary altitudes are calculated.
        Else if lower and upper boundaries are given, the center altitude and
        vertical extent are calculated.
        All variables are in units [km].

        Raises:
            RuntimeError: Raised when inputs are insufficient.
        """

        if (hasattr(self, "center_alt") and hasattr(self, "thick")) and (
            self.center_alt is not None and self.thick is not None
        ):
            if (hasattr(self, "alt_upp") and hasattr(self, "alt_low")) and (
                self.alt_upp is not None and self.alt_low is not None
            ):
                expected_upp, expected_low = utils.calc_layer_extent(
                    float(self.center_alt), float(self.thick)
                )
                if not (
                    np.isclose(self.alt_upp, expected_upp)
                    and np.isclose(self.alt_low, expected_low)
                ):
                    raise ValueError(
                        "Both layer center/thickness and boundary altitudes were "
                        "given, but do not match."
                    )

                return

            else:
                self.alt_upp, self.alt_low = utils.calc_layer_extent(
                    float(self.center_alt), float(self.thick)
                )
                return

        elif (hasattr(self, "alt_upp") and hasattr(self, "alt_low")) and (
            self.alt_upp is not None and self.alt_low is not None
        ):
            self.center_alt, self.thick = utils.calc_layer_bounds(
                float(self.alt_upp), float(self.alt_low)
            )
            return

        else:
            raise RuntimeError(
                """To calculate layer altitude characteristics either
            upper and lower boundary altitude (alt_upp and alt_low) or layer center 
            altitude and vertical extent (center_alt and thick) must be given."""
            )
        return

    def calc_grids(self):
        """Calculates spectral grids for the calculation of optical properties.

        Calculates both wavelengths and wavenumbers.

        """
        self.wvnm, self.wvls = utils.calc_grids(
            lo=self.low_spc, hi=self.upp_spc, res=self.res, units=self.spec_units
        )
        return

    def calc_optical_properties(self):
        """Calculate optical properties.

        In this case all it does is take inp_tau and stretches it over the spectral
        grid. The fact that this is a separate function is because the implementation
        mirrors implementation scheme in other *srfm.layer.Layer()* objects.

        """

        self.tau = np.full(np.asarray(self.wvnm).shape, self.inp_tau, dtype=float)
        return

    @utils.show_runtime
    def regrid(
        self,
        wvls,
        track_diff=False,
        diff_type="pct",
        retain_original=None,
    ):
        """Linearly interpolate optical depth to a new wavelength grid.

        Instance must have the "tau" attribute.

        Args:
            wvls (array-like): New wavelength grid in micrometres.
            track_diff (bool): If True, calculate differences arising from
                interpolation.
            diff_type (str): Difference representation, ``"pct"`` or ``"abs"``.
            retain_original (bool | None): Retain coarse arrays as ``*_old``. ``None``
                preserves the historical behavior; difference tracking always retains
                them.

        Raises:
            ValueError: Raised when any wavelength array is not monotonic.

        """
        if retain_original is None:
            retain_original = True
        retain_original = bool(retain_original or track_diff)

        if retain_original:
            self.wvls_old = np.asarray(self.wvls).copy()
            self.tau_old = np.asarray(self.tau).copy()
        else:
            for attribute_name in ("wvls_old", "tau_old"):
                if hasattr(self, attribute_name):
                    delattr(self, attribute_name)

        target = np.asarray(wvls, dtype=float)
        self.tau = self.interpolate_optical_depth(target)
        self.wvls = target.copy()

        if track_diff:
            self.track_regrid_diff(diff_type=diff_type)

    def interpolate_optical_depth(self, wvls):
        """Interpolate optical depth without modifying the coarse layer data.

        Args:
            wvls (array-like): Target wavelengths in micrometres.

        Returns:
            numpy.ndarray: Optical depth on the requested grid and in its original
            ordering.

        Raises:
            ValueError: If either wavelength grid is empty, non-dimensional, or not
                monotonic.
        """
        target = np.asarray(wvls, dtype=float)
        source = np.asarray(self.wvls, dtype=float)
        values = np.asarray(self.tau, dtype=float)
        if target.ndim != 1 or target.size == 0:
            raise ValueError("Target wavelengths must be a non-empty 1D array.")
        if source.ndim != 1 or source.size == 0:
            raise ValueError("Layer wavelengths must be a non-empty 1D array.")
        if values.shape != source.shape:
            raise ValueError("Layer optical depth must match the wavelength grid.")

        target_order = 1 if target.size < 2 else utils.monotonic(target)
        source_order = 1 if source.size < 2 else utils.monotonic(source)
        if target_order == 0:
            raise ValueError("Target wavelengths are not monotonic.")
        if source_order == 0:
            raise ValueError("Layer wavelengths are not monotonic.")

        interpolation_target = target[::-1] if target_order == 2 else target
        interpolation_source = source[::-1] if source_order == 2 else source
        interpolation_values = values[::-1] if source_order == 2 else values
        interpolated = np.interp(
            interpolation_target,
            interpolation_source,
            interpolation_values,
        )
        return interpolated[::-1] if target_order == 2 else interpolated

    def track_regrid_diff(self, diff_type="pct"):
        """Calculate the difference before and after interpolation.

        Called by :meth:`regrid` when difference tracking is requested.

        Args:
            diff_type (str): "pct" (differences in percent from the old value) or
                "abs" (absolute difference)

        Raises:
            ValueError: Raised when diff_type is invalid.

        """

        diff_dict = {}
        diff_dict["wavelengths"] = self.wvls

        temp_dict = {}
        temp_dict["wavelengths"] = self.wvls
        temp_dict["tau"] = []

        for i in self.wvls:
            x = np.argmin(np.abs(self.wvls_old - np.full(self.wvls_old.size, i)))
            temp_dict["tau"].append(self.tau_old[x])

        for key in temp_dict.keys():
            if key == "wavelengths":
                pass
            else:
                temp_dict[key] = np.asarray(temp_dict[key])

        self.tau_diff = np.abs(temp_dict["tau"] - self.tau)

        if diff_type == "abs":
            return

        elif diff_type == "pct":
            self.tau_diff = (
                np.nan_to_num(np.divide(self.tau_diff, temp_dict["tau"])) * 100
            )
            return
        else:
            raise ValueError("diff_type must be pct or abs.")

        return

    def plot_diff(self, **kwargs):
        """Plot differences in calculated optical properties.

        Instance must have differences in optical properties calculated and stored
        as _diff attributes. For further information see
        ``srfm.layer.track_regrid_diff()``.

        Returns:
            fig (obj): fig object
        """
        fig = plt.figure(figsize=(11.7, 8.3))

        plt.subplot(1, 1, 1)
        plt.plot(self.wvls, self.tau_diff, label="tau")
        plt.xlabel("wavelength (um)", fontsize="12")
        plt.ylabel(r"$\Delta \Tau (\lambda)$ (%)", fontsize="12")
        # plt.yscale("log")
        plt.title("Optical depth", fontsize="15")

        plt.suptitle(
            "Difference in optical properties arising from interpolation", fontsize="18"
        )
        plt.tight_layout()
        return fig
