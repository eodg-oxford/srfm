"""This code defines one function to run srfm.

    Note that the SRFM can be run interactively (i.e. used as a package, use the
    inside of run_srfm() as and example), or with a driver table.

    This module is intended to run the srfm with preprocessed iasi spectra.

    NOTE: Not really sure this module is relevant anymore.

- Name: iasi_main
- Parent package: srfm
- Author: Antonin Knizek
- Contributors:
- Date: 7 Nov 2025
"""

from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
from . import utilities
from . import forward_model
from . import rfm_functions
from . import layer
import os
import sys
import datetime
import time
import warnings
from multiprocessing import Process, Manager
from bisect import bisect
import pickle
from pathlib import Path
import importlib.util
from .RFM import rfm_py
from . import rfm_helper
from .input_schema import validate_iasi_inputs
from .main import (
    _add_grey_body_optical_depth,
    _calculate_output_utau,
    _calculate_optical_layers,
    _construct_and_validate_optical_layers,
    _grey_body_effective_parameters,
    _interpolate_grey_body_optical_depths,
    _interpolate_particle_block,
    _prepare_boundary_spectral_fields,
    _prepare_solar_spectral_irradiance,
    _set_spectral_boundary_inputs,
    _plot_spectral_outputs,
    _resolve_output_geometry,
    _resolve_retained_outputs,
    _write_srfm_netcdf,
    _write_spectral_text,
)


def _format_iasi_plot_title(keystr, model, polar, level, azimuthal):
    """Build the title shared by the IASI spectrum and residual plots."""
    level_name = "altitude (km)" if model.output_format == "altitude" else "optical depth"
    return (
        f"{keystr}\nOutput polar angle: {model.output_polar_angles[polar]:g}°; "
        f"{level_name}: {model.output_values[level]:g}; "
        f"azimuthal angle: {model.output_azimuthal_angles[azimuthal]:g}°"
    )


@utilities.show_runtime
def run_srfm(inp):
    """Run the memory-efficient SRFM pathway for preprocessed IASI data.

    Optimized for IASI data.

    Args:
        inp (obj): Instance of inputs.Inputs.

    Returns:
        model_SRFM (obj): Instance of forward_model.SRFM.

    Raises:
        TypeError: If ``inp`` does not provide a ``values`` mapping.
        InputValidationError: If configured IASI inputs are invalid.
        RuntimeError: If RFM capture or a native model calculation fails.
        ValueError: If spectral, atmospheric, or output geometry is inconsistent.

    """
    if not hasattr(inp, "values"):
        raise TypeError("run_srfm expects an Inputs-like object with a values mapping.")
    inp.values = validate_iasi_inputs(inp.values)
    requested_wavenumber, _ = utilities.calc_grids(
        inp.values["spc_wvnmlo"],
        inp.values["spc_wvnmhi"],
        inp.values["spc_res"],
        inp.values["spc_units"],
    )
    prepared_albedo, prepared_custom_solar = _prepare_boundary_spectral_fields(
        inp.values, requested_wavenumber
    )
    scat_lyrs, prescribed_lyrs, gbc_lyrs = _construct_and_validate_optical_layers(
        inp.values, requested_wavenumber
    )
    _calculate_optical_layers(
        scat_lyrs,
        gbc_lyrs,
        inp.values.get("retain_phase_functions", False),
    )
    particle_lyrs = {**scat_lyrs, **prescribed_lyrs}
    ########################################################################################
    # Assign some variables:
    ########################################################################################
    # Keep all run-generated files outside the installed package tree.
    os.makedirs(inp.values["results_fldr"], exist_ok=True)

    ########################################################################################
    # set iasi grid and final grid to interpolate to
    ########################################################################################
    npts = (
        int(
            np.floor(
                (inp.values["fin_wvnmhi"] - inp.values["fin_wvnmlo"])
                / inp.values["fin_res"]
            )
        )
        + 1
    )  # expected number of points in the grid
    fin_grid = inp.values["fin_wvnmlo"] + np.arange(npts) * inp.values["fin_res"]

    iasi_npts = int(np.floor((2760 - 645) / 0.25)) + 1
    iasi_grid = 645 + np.arange(iasi_npts) * 0.25

    ########################################################################################
    # pick an iasi spectral file (processed)
    ########################################################################################
    iasi_spc_fldr = inp.values["iasi_spc_fldr"]
    iasi_fl = inp.values["iasi_fl"]  # A for ascending, D for descending
    date = datetime.datetime.strptime(
        iasi_fl[iasi_fl.find("_") + 1 : iasi_fl.rfind("_")], "%Y%m%d"
    )
    year_day = date.timetuple().tm_yday

    ########################################################################################
    # load corresponding spectral file
    ########################################################################################
    with open(os.path.join(iasi_spc_fldr, iasi_fl), "rb") as f:
        iasi_data = pickle.load(f)
    f.close()

    # pick pixel (manually check the file first and pick a pixel
    px = inp.values[
        "px"
    ]  # the only pixel with 0% cloud cover on this day in the ascending orbit for hlat ssacc
    keystr = iasi_fl[: iasi_fl.find(".")] + f"_px{px}"

    iasi_out_spc = iasi_data["spec_bbt"][px, :]

    iasi_out_spc = np.interp(fin_grid, iasi_grid, iasi_out_spc)

    iasi_out_zen_deg = iasi_data["zen"][px]  # zenith angle [degrees]

    iasi_out_zen_rad = np.deg2rad(iasi_out_zen_deg)  # avg zenith angle [rad]
    iasi_zen_cos = np.cos(iasi_out_zen_rad).item()  # cosine of the zenith angle
    iasi_zen_sec = 1 / iasi_zen_cos  # secant of zenith angle
    # secant is for RFM, currently unused

    ########################################################################################
    # prepare ECMWF data (now from the spectral file)
    ########################################################################################
    z = iasi_data["ecmwf_z"][px][::-1]  # altitude grid

    slc_idx = next((index for index, value in enumerate(list(z)) if value > 0), None)

    # crop leading negative values
    z = z[slc_idx:]

    # load other ecmwf data
    T = iasi_data["ecmwf_T"][px][::-1][slc_idx:]
    p = iasi_data["ecmwf_p"][px][::-1][slc_idx:]
    o3 = iasi_data["ecmwf_O3"][px][::-1][slc_idx:]
    co = iasi_data["ecmwf_CO"][px][::-1][slc_idx:]
    n2o = iasi_data["ecmwf_N2O"][px][::-1][slc_idx:]
    co2 = iasi_data["ecmwf_CO2"][px][::-1][slc_idx:]
    ch4 = iasi_data["ecmwf_CH4"][px][::-1][slc_idx:]
    h2o = iasi_data["ecmwf_H2O"][px][::-1][slc_idx:]

    # read current rfm .atm file used to specify the atmosphere
    rfm_prf = rfm_functions.read_atm_file(inp.values["driver_inputs"]["atmosphere"][1])

    """The existing rfm data is bisected such that the levels which overlap with the
    ecmwf data levels are selected. On this part of the profile, the ecmwf data are used
    (interpolated to the .atm grid). The ecmwf data ends at ~75-80 km, so rfm day.atm 
    data are used above that point.    
    """
    b_idx = bisect(
        rfm_prf["HGT [km]"], z[-1]
    )  # bisect existing profile at end of ecmwf data

    z_lo = rfm_prf["HGT [km]"][:b_idx]

    # keep profiles where there's no ecmwf data (higher up in the atmosphere)
    new_T_hi = rfm_prf["TEM [K]"][b_idx:]
    new_p_hi = rfm_prf["PRE [mb]"][b_idx:]
    new_o3_hi = rfm_prf["O3 [ppmv]"][b_idx:]
    new_co_hi = rfm_prf["CO [ppmv]"][b_idx:]
    new_n2o_hi = rfm_prf["N2O [ppmv]"][b_idx:]
    new_co2_hi = rfm_prf["CO2 [ppmv]"][b_idx:]
    new_ch4_hi = rfm_prf["CH4 [ppmv]"][b_idx:]
    new_h2o_hi = rfm_prf["H2O [ppmv]"][b_idx:]

    # interpolate ecmwf data to the altitude grid from the .atm file, overlapping part
    new_T_lo = np.interp(z_lo, z, T)
    new_p_lo = np.interp(z_lo, z, p)
    new_o3_lo = np.interp(z_lo, z, o3)
    new_co_lo = np.interp(z_lo, z, co)
    new_n2o_lo = np.interp(z_lo, z, n2o)
    new_co2_lo = np.interp(z_lo, z, co2)
    new_ch4_lo = np.interp(z_lo, z, ch4)
    new_h2o_lo = np.interp(z_lo, z, h2o)

    # concatenate the two parts of the array
    new_T = np.concatenate((new_T_lo, np.array(new_T_hi)))
    new_p = np.concatenate((new_p_lo, np.array(new_p_hi)))
    new_o3 = np.concatenate((new_o3_lo, np.array(new_o3_hi)))
    new_co = np.concatenate((new_co_lo, np.array(new_co_hi)))
    new_n2o = np.concatenate((new_n2o_lo, np.array(new_n2o_hi)))
    new_co2 = np.concatenate((new_co2_lo, np.array(new_co2_hi)))
    new_ch4 = np.concatenate((new_ch4_lo, np.array(new_ch4_hi)))
    new_h2o = np.concatenate((new_h2o_lo, np.array(new_h2o_hi)))

    if inp.values["plot_profiles"] == True:
        # plot old and new profiles and save figure
        fig, axs = plt.subplots(2, 4, figsize=(11.7, 8.3), sharey=True)
        plt.rcParams.update({"font.size": 14})
        fig.supylabel("Altitude (km)")

        axs[0, 0].plot(rfm_prf["TEM [K]"], rfm_prf["HGT [km]"], label="rfm")
        axs[0, 0].plot(new_T, rfm_prf["HGT [km]"], label="ecmwf+rfm")
        axs[0, 0].set_xlabel("T (K)")
        axs[0, 0].legend()

        axs[0, 1].plot(rfm_prf["PRE [mb]"], rfm_prf["HGT [km]"], label="rfm")
        axs[0, 1].plot(new_p, rfm_prf["HGT [km]"], label="ecmwf+rfm")
        axs[0, 1].set_xlabel("p (mb)")
        axs[0, 1].legend()

        axs[0, 2].plot(rfm_prf["O3 [ppmv]"], rfm_prf["HGT [km]"], label="rfm")
        axs[0, 2].plot(new_o3, rfm_prf["HGT [km]"], label="ecmwf+rfm")
        axs[0, 2].set_xlabel(r"$x_{O_{3}}$ (ppmv)")
        axs[0, 2].legend()

        axs[0, 3].plot(rfm_prf["CO [ppmv]"], rfm_prf["HGT [km]"], label="rfm")
        axs[0, 3].plot(new_co, rfm_prf["HGT [km]"], label="ecmwf+rfm")
        axs[0, 3].set_xlabel(r"$x_{CO}$ (ppmv)")
        axs[0, 3].legend()

        axs[1, 0].plot(rfm_prf["N2O [ppmv]"], rfm_prf["HGT [km]"], label="rfm")
        axs[1, 0].plot(new_n2o, rfm_prf["HGT [km]"], label="ecmwf+rfm")
        axs[1, 0].set_xlabel(r"$x_{N_{2}O}$ (ppmv)")
        axs[1, 0].legend()

        axs[1, 1].plot(rfm_prf["CO2 [ppmv]"], rfm_prf["HGT [km]"], label="rfm")
        axs[1, 1].plot(new_co2, rfm_prf["HGT [km]"], label="ecmwf+rfm")
        axs[1, 1].set_xlabel(r"$x_{CO_{2}}$ (ppmv)")
        axs[1, 1].legend()

        axs[1, 2].plot(rfm_prf["CH4 [ppmv]"], rfm_prf["HGT [km]"], label="rfm")
        axs[1, 2].plot(new_ch4, rfm_prf["HGT [km]"], label="ecmwf+rfm")
        axs[1, 2].set_xlabel(r"$x_{CH_{4}}$ (ppmv)")
        axs[1, 2].legend()

        axs[1, 3].plot(rfm_prf["H2O [ppmv]"], rfm_prf["HGT [km]"], label="rfm")
        axs[1, 3].plot(new_h2o, rfm_prf["HGT [km]"], label="ecmwf+rfm")
        axs[1, 3].set_xlabel(r"$x_{H_{2}O}$ (ppmv)")
        axs[1, 3].set_xscale = "log"
        axs[1, 3].legend()

        # plt.suptitle(f"Comparison between original rfm and interpolated ecmwf+rfm profiles\n{keystr[1:keystr.rfind('.')]}")
        plt.suptitle(
            f"Comparison between original rfm and interpolated ecmwf+rfm profiles\n{keystr}"
        )

        plt.tight_layout()
        plt.savefig(f"{inp.values['results_fldr']}/{keystr}_prf.png")
        plt.close()

    #######################################################################################
    # work out where to insert a liquid water cloud
    #######################################################################################

    # (exclude region above 2200 cm-1 where reflected solar radiation starts to matter)
    lim = (
        fin_grid[-1] if fin_grid[-1] < 2200 else 2200
    )  # determine where to cut off the
    # spectrum for looking for the maximum observed bbt

    # index of maximum observed bbt in the truncated spectrum, which is in theory the
    # observed blackbody temperature + instrument noise
    max_obs_bbt_idx = iasi_out_spc[0 : np.absolute(iasi_grid - lim).argmin()].argmax()

    obs_bbt = iasi_out_spc[max_obs_bbt_idx]  # maximum observed temperature

    obs_bbt_wvnm = fin_grid[max_obs_bbt_idx]  # wavenumber corresponding to the
    # maximum in the spectrum

    # check for ambiguity (should not happen, this is just check, not a fix)
    if not isinstance(obs_bbt_wvnm, float):
        raise RuntimeError(
            """Ambiguity encountered. Multiple wavenumbers matched to the
        maximum brightness temperature value. Can't assign noise equivalent delta
        temperature."""
        )

    #     concept of the following few lines:
    #     1. Assumption 1: The main cause of noise in the spectrum is instrument noise.
    #     2. iasi_nedt.txt is a file that contains iasi NEDT @280K, see the file for details
    #     3. I interpolate the nedt to obs_bbt_wvnm
    #     4. Since this is noise, I take the value*1/2 and subtract from obs_bbt
    #     5. In this way I have hopefully removed the effect of noise from my reading.
    #     6. Assumption 2: obs_bbt does not coincide with a strong absorption line (ie is
    #        truly from a black/grey body.
    #     7. Assumption 3: NEDT is taken just as the instrument noise at 280K, no
    #        interpolation to other temperatures (generally in this case, the difference
    #        should be <20 K anyway.
    #     8. Assumption 3: Scene specific NEDT is not used (see Vincent, A, Retrieval of
    #        trace gases using IASI, thesis, Univ Oxford (EODG), 2016
    #     9. Assumption 4: The noise is random and taking a mean, or halving it, makes sense.

    # open iasi noise equivalent delta temperature file
    nedt = np.loadtxt(inp.values["nedt"], skiprows=3)  # [[wvnm,nedt]]

    # interpolate to obs_bbt_wvnm
    obs_bbt_nedt = np.interp(obs_bbt_wvnm, nedt[:, 0], nedt[:, 1])

    # subtract half of the noise value from the temperature value
    obs_bbt = obs_bbt - obs_bbt_nedt / 2

    # find tropopause (min in TEM profile between 0 and 30 km, 30 is arbitrary)
    tropopause_idx = rfm_prf["TEM [K]"].index(min(rfm_prf["TEM [K]"][0:30]))

    # get the altitude from a the ecmwf profile that corresponds to this temperature
    # the profile is linearly interpolated.
    corr_alt = np.interp(
        obs_bbt,
        rfm_prf["TEM [K]"][1:tropopause_idx][::-1],  # the slice [1:10] is to avoid
        # the fact that the temperature profile isn't monotonic with
        # altitude. Using the first ten values should both be
        # sufficient to capture clouds and small enough to avoid
        # encountering the cold trap temperature.
        # The profile is inverted for interpolation purposes, because
        # np.interp requires strictly increasing values in abscissa.
        rfm_prf["HGT [km]"][1:tropopause_idx][::-1],
    )
    corr_alt = round(corr_alt, 3)
    corr_alt = corr_alt.item()

    #######################################################################################
    # update rfm profiles with data from previous two sections
    #######################################################################################

    #     update first temperature in the profile according to the maximum observed temperature
    #     minus nedt. The logic being that if there's no cloud, this correspond to surface
    #     temperature. This is necessary since the spectrum is sensitive to surface temperature
    #     and ecmwf data may be inaccurate in this. If there is a cloud, then the surface
    #     temperature does not matter anyway.
    #     new_T[0] = iasi_out_spc[max_obs_bbt_idx]

    #     update rfm_prf
    rfm_prf["TEM [K]"] = new_T
    rfm_prf["PRE [mb]"] = new_p
    rfm_prf["O3 [ppmv]"] = new_o3
    rfm_prf["CO [ppmv]"] = new_co
    rfm_prf["N2O [ppmv]"] = new_n2o
    rfm_prf["CO2 [ppmv]"] = new_co2
    rfm_prf["CH4 [ppmv]"] = new_ch4
    rfm_prf["H2O [ppmv]"] = new_h2o

    # set profiles of species to retrieve
    if "g_rtv" in inp.values.keys():
        for key in inp.values["g_rtv"]:
            rfm_prf[key] = inp.values["g_rtv"][key]

    # save output profile
    rfm_functions.write_atm_file(
        data=rfm_prf,
        filename=f"{inp.values['results_fldr']}/{keystr}.atm",
        header=f"""!Combination of (ecmwf) and MID-LATITUDE DAY PROFILES FOR MIPAS
        !by Anu Dudhia.\n""",
    )

    ########################################################################################
    # specify spectral calculation grid
    ########################################################################################
    spec_res = inp.values["spc_res"]  # model spectral resolution,[spec_units]
    low_spc = inp.values["spc_wvnmlo"]  # model start wavenumber (lower), [spec_units]
    upp_spc = inp.values["spc_wvnmhi"]  # model end wavenumber (upper), [spec_units]
    spec_units = inp.values["spc_units"]  # accepted values "cm-1", "um", "nm"

    RFM_wvnm, wvls = utilities.calc_grids(low_spc, upp_spc, spec_res, spec_units)

    rfm_grid_fname = rfm_functions.construct_rfm_grid_file(
        RFM_wvnm, filename="grid.spc", rfm_fldr=inp.values["results_fldr"]
    )

    ########################################################################################
    # prepare atmospheric layer structure
    ########################################################################################

    # define some requested output levels
    if "levels" in inp.values.keys():
        levels = inp.values["levels"]
    else:
        levels = [
            0.0,
            1.0,
            2.0,
            3.0,
            4.0,
            5.0,
            6.0,
            7.0,
            8.0,
            9.0,
            10.0,
            11.0,
            12.0,
            13.0,
            14.0,
            15.0,
            16.0,
            17.0,
            18.0,
            19.0,
            20.0,
            21.0,
            22.0,
            23.0,
            24.0,
            25.0,
            27.5,
            30.0,
            32.5,
            35.0,
            37.5,
            40.0,
            42.5,
            45.0,
            47.5,
            50.0,
            55.0,
            60.0,
            65.0,
            70.0,
            75.0,
            80.0,
            85.0,
            90.0,
            95.0,
            100.0,
            115.0,
            120.0,
        ]

    # define tracker array for atmospheric structure
    track_lev = [None for i in levels]

    # add upper and lower particle layer boundaries, delete any levels "within" the layer
    for lyr in scat_lyrs.keys():
        levels, track_lev = utilities.add_lyr_from_Layer(
            lev=levels, track_lev=track_lev, new_lyr=scat_lyrs[lyr]
        )

    for lyr in prescribed_lyrs:
        levels, track_lev = utilities.add_lyr_from_Layer(
            lev=levels, track_lev=track_lev, new_lyr=prescribed_lyrs[lyr]
        )

    for lyr in gbc_lyrs:
        levels, track_lev = utilities.add_lyr_from_Layer(
            lev=levels, track_lev=track_lev, new_lyr=gbc_lyrs[lyr]
        )

    # convert the tracking levels array to a tracking layers array
    track_lyr = utilities.track_lev_to_track_lyr(track_lev)
    track_lyr = track_lyr[::-1]

    ########################################################################################
    # prepare and call RFM
    ########################################################################################
    # RFM global config
    rfm_config = inp.values["rfm_config"]

    # RFM driver table
    driver_inputs = inp.values["driver_inputs"]
    driver_inputs["tangent"] = (str(iasi_zen_sec),)
    driver_inputs["lev"] = tuple(str(val) for val in levels)
    driver_inputs["atmosphere"] = list(driver_inputs["atmosphere"])
    driver_inputs["atmosphere"].append(f"{inp.values['results_fldr']}/{keystr}.atm")
    driver_inputs["atmosphere"] = tuple(driver_inputs["atmosphere"])

    if "btemp" in inp.values:
        driver_inputs["sfc"] = (f"TEMSFC={inp.values['btemp']}",)
    # initialize RFM model class
    model_RFM = forward_model.RFM()

    # print current status:
    print(model_RFM.status)

    # run rfm
    rfm_run_result = rfm_helper.rfm_main(
        configuration=rfm_config,
        driver_inputs=driver_inputs,
        levels=levels,
        rfm_out_fldr=inp.values["results_fldr"],
    )
    model_RFM.rfm_run_result = rfm_run_result
    if rfm_run_result.optical_depth_grid is None:
        raise RuntimeError("RFM capture did not return a compact optical-depth grid.")
    model_RFM.rfm_output = rfm_run_result.optical_depth_grid

    # print current status:
    print(model_RFM.status)

    RFM_wvnm = model_RFM.rfm_output.wavenumber
    wvls = (1.0 / RFM_wvnm) * 1e4
    if isinstance(prepared_albedo, float):
        surface_albedo = prepared_albedo
    else:
        surface_albedo = prepared_albedo.interpolate(RFM_wvnm)
    grey_body_optical_depths = _interpolate_grey_body_optical_depths(
        gbc_lyrs, wvls
    )

        # Prepare dict with layer parameters to be saved in the output
    layer_attrs = (
        "name",
        "low_spc",
        "upp_spc",
        "spec_units",
        "res",
        "mass_loading",
        "n",
        "r",
        "s",
        "rho",
        "s_a_den",
        "v_den",
        "dist_type",
        "comp",
        "center_alt",
        "thick",
        "alt_low",
        "alt_upp",
        "radii",
        "eta",
        "phase_quad_N",
        "phase_quad_type",
        "radii_quad_type",
        "leg_coeffs",
        "leg_coeffs_type",
        "multiprocess",
    )

    effective_params = dict(inp.values)
    effective_params["scat_lyrs_inputs"] = {
        lyr: {"layer_type": "mie"}
        | {
            attr: getattr(scat_lyrs[lyr], attr)
            for attr in layer_attrs
            if hasattr(scat_lyrs[lyr], attr)
        }
        for lyr in scat_lyrs
    }
    effective_params["prescribed_lyrs_inputs"] = {
        lyr: prescribed_lyrs[lyr].source_metadata() for lyr in prescribed_lyrs
    }
    effective_params["gbc_lyrs_inputs"] = _grey_body_effective_parameters(gbc_lyrs)
    effective_params["albedo"] = (
        prepared_albedo
        if isinstance(prepared_albedo, float)
        else prepared_albedo.provenance()
    )
    if prepared_custom_solar is not None:
        effective_params["solar_spectrum"] = prepared_custom_solar.provenance()

    ########################################################################################
    # prepare DISORT common variables
    ########################################################################################

    # initialize DISORT model class
    model_DISORT = forward_model.DISORT(retain_history=False)

    # check if number of columns and wavelengths match
    if model_RFM.rfm_output.differential_tau.shape[0] != len(wvls):
        raise ValueError(
            f"Number of RFM and scattering wavelengths don't match "
            f"({model_RFM.rfm_output.differential_tau.shape[0]} optical-depth rows "
            f"vs {len(wvls)} scattering wavelengths)."
        )
    output_values, altitude_rows = _resolve_output_geometry(
        inp.values["out_fmt"],
        inp.values["out"],
        inp.values["out_toa"],
        model_RFM.rfm_output,
    )

    # set disort_input parameters common to all loop iterations
    # these need to be set first:
    nmom = inp.values["nmom"]
    for particle_layer in particle_lyrs.values():
        nmom = max(nmom, particle_layer.required_nmom)

    model_DISORT.set_maxcmu(inp.values["maxcmu"])

    model_DISORT.set_maxmom(nmom)
    if nmom < model_DISORT.disort_input["maxcmu"]:
        model_DISORT.set_maxmom(model_DISORT.disort_input["maxcmu"])
    nmom = model_DISORT.disort_input["maxmom"]

    model_DISORT.set_maxumu(inp.values["maxumu"])
    model_DISORT.set_maxphi(inp.values["maxphi"])
    model_DISORT.set_maxulv(len(output_values))
    effective_params["maxulv"] = len(output_values)

    # now the rest
    model_DISORT.set_usrang(inp.values["usrang"])
    model_DISORT.set_usrtau(inp.values["usrtau"])
    model_DISORT.set_ibcnd(inp.values["ibcnd"])
    model_DISORT.set_onlyfl(inp.values["onlyfl"])
    # model_DISORT.set_prnt([True, True, True, False, False])
    model_DISORT.set_prnt(inp.values["prnt"])
    model_DISORT.set_plank(inp.values["planck"])
    model_DISORT.set_lamber(inp.values["lamber"])
    model_DISORT.set_deltamplus(inp.values["deltamplus"])
    model_DISORT.set_do_pseudo_sphere(inp.values["do_pseudo_sphere"])

    model_DISORT.set_fisot(inp.values["fisot"])
    if isinstance(surface_albedo, float):
        model_DISORT.set_albedo(surface_albedo)

    model_DISORT.set_temis(inp.values["temis"])
    model_DISORT.set_earth_radius(inp.values.get("earth_radius", 6371.0))
    model_DISORT.set_rhoq(
        np.zeros(
            shape=(
                int(model_DISORT.disort_input["maxcmu"] / 2),
                int(model_DISORT.disort_input["maxcmu"] / 2 + 1),
                int(model_DISORT.disort_input["maxcmu"]),
            )
        )
    )
    model_DISORT.set_rhou(
        np.zeros(
            shape=(
                model_DISORT.disort_input["maxumu"],
                int(model_DISORT.disort_input["maxcmu"] / 2 + 1),
                model_DISORT.disort_input["maxcmu"],
            )
        )
    )
    model_DISORT.set_rho_accurate(
        np.zeros(
            shape=(
                model_DISORT.disort_input["maxumu"],
                model_DISORT.disort_input["maxphi"],
            )
        )
    )
    model_DISORT.set_bemst(
        np.zeros(shape=(int(model_DISORT.disort_input["maxcmu"] / 2)))
    )
    model_DISORT.set_emust(np.zeros(shape=(model_DISORT.disort_input["maxumu"])))
    model_DISORT.set_accur(0)
    ########################################################################################
    # prepare solar spectrum
    ########################################################################################

    solar_enabled = inp.values.get("sun", True)
    solar_spc = _prepare_solar_spectral_irradiance(
        prepared_custom_solar,
        RFM_wvnm,
        year_day,
        sun=solar_enabled,
    )
    if solar_enabled:
        solar_zen_deg = iasi_data["sza"][px]
        solar_zen_rad = np.deg2rad(solar_zen_deg)
        model_DISORT.set_umu0(np.cos(solar_zen_rad).item())
        model_DISORT.set_phi0(iasi_data["saa"][px])
    else:
        model_DISORT.set_umu0(1)
        model_DISORT.set_phi0(0)
    model_DISORT.set_umu([iasi_zen_cos])
    model_DISORT.set_phi([iasi_data["azi"][px]])

    # initialize disort input arrays for output variables from a single run
    model_DISORT.initialize_disort_output_arrays()

    ########################################################################################
    # set DISORT DISOBRDF variables
    ########################################################################################

    # TBD

    ########################################################################################
    # prepare SRFM common variables
    ########################################################################################
    model_SRFM = forward_model.SRFM()
    model_SRFM.set_wvnm(RFM_wvnm)
    model_SRFM.set_wvls(wvls)
    requested_outputs, runtime_outputs = _resolve_retained_outputs(inp.values)
    # IASI always convolves simulated radiance, even when it is not retained.
    runtime_outputs.add("uu")
    model_SRFM.initialize_srfm_output_arrays_from_disort(
        model_DISORT, retain_outputs=runtime_outputs
    )
    model_SRFM.output_format = inp.values["out_fmt"]
    model_SRFM.output_values = output_values
    model_SRFM.output_polar_angles = np.asarray([iasi_out_zen_deg], dtype=float)
    model_SRFM.output_azimuthal_angles = np.asarray(
        [iasi_data["azi"][px]], dtype=float
    )

    # track progress
    pct = [
        1,
        2,
        5,
        10,
        20,
        30,
        40,
        50,
        60,
        70,
        80,
        90,
        100,
    ]  # percent completed to report
    pct_val = [RFM_wvnm[int(i * len(RFM_wvnm) / 100 - 1)] for i in pct]

    ########################################################################################
    # set dynamic variables and run DISORT
    ########################################################################################
    scattering_block_size = inp.values.get("scattering_block_size", 10000)
    particle_block = {}
    particle_block_start = 0
    skipped_scattering = {
        layer_name: {"count": 0, "first": None, "last": None}
        for layer_name in particle_lyrs
    }
    for wvl_idx, (wvnm, wvl, tau_g) in enumerate(
        zip(RFM_wvnm, wvls, model_RFM.rfm_output.differential_tau)
    ):
        if particle_lyrs and wvl_idx % scattering_block_size == 0:
            particle_block_start = wvl_idx
            block_stop = min(wvl_idx + scattering_block_size, len(wvls))
            particle_block = _interpolate_particle_block(
                particle_lyrs,
                RFM_wvnm[wvl_idx:block_stop],
                nmom,
            )
        block_index = wvl_idx - particle_block_start

        # track progress
        if wvnm in pct_val:
            val_idx = pct_val.index(wvnm)
            print(f"Running main DISORT loop. {pct[val_idx]}% done...")

        #        model_DISORT.set_header(f"Now starting calculation for {col} cm-1.")
        model_DISORT.set_header(
            "NO HEADER"
        )  # the string "NO HEADER" will cause no printout
        model_DISORT.set_wvnm(wvnm)
        model_DISORT.set_wvl(wvl)

        tau_g = _add_grey_body_optical_depth(
            tau_g,
            track_lyr,
            grey_body_optical_depths,
            wvl_idx,
        )

        # layer optical depths from Rayleigh scattering
        #    tau_R = np.zeros(shape=(tau_g.shape))
        tau_R = utilities.calc_Rayleigh_opt_depths(
            ps=model_RFM.rfm_output.pressure_lower[-1],
            pu=model_RFM.rfm_output.pressure_upper,
            pl=model_RFM.rfm_output.pressure_lower,
            l=wvnm,
        )

        # particle layer optical depths (from particle scattering)
        tau_p = np.zeros(shape=(len(tau_g)))
        for lyr in particle_lyrs:
            tau_p[track_lyr.index(lyr)] = particle_block[lyr][
                "particle_optical_depth"
            ][block_index]

        # particle layer single scatter albedo
        w_p = np.zeros(shape=(len(tau_g)))
        for lyr in particle_lyrs:
            w_p[track_lyr.index(lyr)] = particle_block[lyr][
                "single_scattering_albedo"
            ][block_index]

        dtauc_tot = utilities.calc_tot_dtauc(tau_g=tau_g, tau_R=tau_R, tau_p=tau_p)
        dtauc_tot = np.maximum(np.asarray(dtauc_tot, dtype=float), 0.0)

        # truncate optical depths
        threshold_od = 1e-8  # threshold at which to truncate optical depths
        significant_layers = np.flatnonzero(dtauc_tot > threshold_od)
        idx = int(significant_layers[0]) if significant_layers.size else 0

        utau = _calculate_output_utau(
            inp.values["out_fmt"],
            output_values,
            altitude_rows,
            dtauc_tot,
            idx,
        )
        model_DISORT.set_utau(utau)

        dtauc_tot = dtauc_tot[idx:]
        tau_g = tau_g[idx:]
        tau_R = tau_R[idx:]
        tau_p = tau_p[idx:]
        w_p = w_p[idx:]
        track_lyr_local = track_lyr[idx:]

        # set layer optical depths
        model_DISORT.set_dtauc_manually(dtauc=dtauc_tot)
        model_DISORT.disort_input["dtauc"][model_DISORT.disort_input["dtauc"] < 0] = 0

        # set maxcly based on current length of tau_g
        model_DISORT.set_maxcly(len(dtauc_tot))

        ## set some maxcly-dependent DISORT input variables

        # set and truncate temper
        model_DISORT.set_temper_from_rfm(model_RFM)
        model_DISORT.disort_input["temper"] = model_DISORT.disort_input["temper"][idx:]

        # set bottom boundary temperature
        if "btemp" in inp.values:
            model_DISORT.set_btemp(inp.values["btemp"])
        else:
            model_DISORT.set_btemp(model_DISORT.disort_input["temper"][-1])

        # set top boundary temperature
        if "ttemp" in inp.values:
            model_DISORT.set_ttemp(inp.values["ttemp"])
        else:
            model_DISORT.set_ttemp(model_DISORT.disort_input["temper"][0])

        model_DISORT.set_h_lyr(
            np.zeros(shape=(model_DISORT.disort_input["maxcly"] + 1))
        )

        # set single scatter albedo
        model_DISORT.set_ssalb(tau_g=tau_g, tau_R=tau_R, tau_p=tau_p, w_p=w_p)

        particle_moments = {}
        for lyr in particle_lyrs:
            layer_tau = particle_block[lyr]["particle_optical_depth"][block_index]
            layer_ssalb = particle_block[lyr]["single_scattering_albedo"][block_index]
            if layer_tau * layer_ssalb < threshold_od:
                skipped = skipped_scattering[lyr]
                skipped["count"] += 1
                skipped["first"] = wvnm if skipped["first"] is None else skipped["first"]
                skipped["last"] = wvnm
            else:
                coefficients = particle_block[lyr][
                    "normalized_legendre_coefficients"
                ][block_index].copy()
                if (
                    abs(coefficients[0] - 1.0)
                    > layer.NORMALIZED_MOMENT_TOLERANCE
                ):
                    raise RuntimeError(
                        "Something is wrong with the phase function. The first "
                        f"coefficient is {coefficients[0]}, but should be 1.0. "
                        "Try increasing number of quadrature points."
                    )
                coefficients[0] = 1.0
                particle_moments[track_lyr_local.index(lyr)] = coefficients

        model_DISORT.set_mixed_pmom(
            tau_R=tau_R,
            w_p=w_p,
            tau_p=tau_p,
            particle_moments=particle_moments,
            prec=inp.values["disort_precision"],
        )
        #    print(model_DISORT.disort_input["pmom"]).shape

        # set wavenumber range for DISORT (for Planck function)
        model_DISORT.set_wvnm_range(wvnm - 0.5, wvnm + 0.5)

        _set_spectral_boundary_inputs(
            model_DISORT,
            wvl_idx,
            surface_albedo,
            solar_spc,
            sun=solar_enabled,
        )
        #    model_DISORT.set_fbeam(0.1)

        # run disort input tests
        # see main.py for comment
        #        model_DISORT.test_disort_input_format()
        #        model_DISORT.test_disort_input_integrity()

        # call DISOBRDF
        #    model_DISORT.run_disobrdf(prec=inp.values["disort_precision"],
        #                              debug=False,
        #                              brdf_type=2, # Cox-Munk
        #                              brdf_arg=[1,1.34,False,0], # wind speed, water refractive index, do_shadow
        #                              nmug=200) # number of quadrature angles
        # run disort
        disort_result = model_DISORT.run_disort(prec=inp.values["disort_precision"],adjust_maxcmu=inp.values["adjust_maxcmu"],)

        # store result in SRFM()
        model_SRFM.store_disort_result(disort_result, wvl_idx)

        # print current status
    #    print(model_DISORT.status)
    print("Main DISORT loop finished.")
    for layer_name, skipped in skipped_scattering.items():
        if skipped["count"]:
            warnings.warn(
                f"Particle layer {layer_name!r} was below scattering optical-depth threshold "
                f"{threshold_od:g} at {skipped['count']} wavenumbers from "
                f"{skipped['first']:g} to {skipped['last']:g} cm-1; particle "
                "scattering was omitted there.",
                stacklevel=2,
            )

    # convolve final radiance spectrum with iasi instrument line shape
    model_SRFM.convolve_with_iasi(inp.values["ils"])

    # interpolate resulting bbt and radiances to final grid
    model_SRFM.interp(fin_grid)

    if "bbt" in requested_outputs:
        model_SRFM.calc_bbt()
    if "uu" not in requested_outputs and hasattr(model_SRFM, "uu"):
        delattr(model_SRFM, "uu")
        model_SRFM.retained_outputs = frozenset(
            set(model_SRFM.retained_outputs) - {"uu"}
        )

    ########################################################################################
    # (optional) save spectrum to file
    ########################################################################################
    if inp.values["out_mode"] == "txt":
        if "bbt" in requested_outputs:
            _write_spectral_text(
                os.path.join(inp.values["results_fldr"], "bbt.txt"),
                model_SRFM.wvnm,
                model_SRFM.bbt,
                "Brightness temperature (K)",
            )

        if "uu" in requested_outputs:
            _write_spectral_text(
                os.path.join(inp.values["results_fldr"], "rad.txt"),
                model_SRFM.wvnm,
                model_SRFM.uu,
                "Radiance (W m-2 sr-1 cm)",
            )

    elif inp.values["out_mode"] == "netcdf":
        out_nm = os.path.join(
            inp.values["results_fldr"], inp.values.get("out_fname") or "srfm.nc"
        )
        _write_srfm_netcdf(
            out_nm,
            model_SRFM,
            inp.values["retain_outputs"],
            effective_params,
            RFM_wvnm,
            particle_lyrs,
            grey_body_layers=gbc_lyrs,
            surface_albedo=surface_albedo,
            solar_spectral_irradiance=solar_spc,
            nmom=nmom,
            scattering_block_size=scattering_block_size,
        )

    elif inp.values["out_mode"] == None:
        pass

    if inp.values["base_plots"] == True and "bbt" in requested_outputs:
        for polar in range(model_SRFM.bbt.shape[1]):
            for level in range(model_SRFM.bbt.shape[2]):
                for azimuthal in range(model_SRFM.bbt.shape[3]):
                    suffix = f"{polar}_{level}_{azimuthal}"
                    title = _format_iasi_plot_title(
                        keystr, model_SRFM, polar, level, azimuthal
                    )
                    simulated = model_SRFM.bbt[:, polar, level, azimuthal]

                    plt.figure(figsize=(11.7, 8.4))
                    plt.rcParams.update({"font.size": 12})
                    plt.plot(
                        model_SRFM.wvnm,
                        simulated,
                        label="SRFM",
                        color="tab:blue",
                    )
                    plt.plot(
                        fin_grid,
                        iasi_out_spc,
                        label="IASI",
                        color="tab:orange",
                    )
                    plt.xlabel(r"Wavenumbers (cm$^{-1}$)")
                    plt.ylabel("Brightness temperature (K)")
                    plt.legend()
                    plt.title(title)
                    plt.savefig(
                        os.path.join(
                            inp.values["results_fldr"],
                            f"{keystr}_spc_vs_iasi_{suffix}.png",
                        )
                    )
                    if inp.values["show_plots"] == True:
                        plt.show()
                    plt.close()

                    plt.figure(figsize=(11.7, 8.4))
                    plt.rcParams.update({"font.size": 12})
                    plt.plot(
                        model_SRFM.wvnm,
                        simulated - iasi_out_spc,
                        label="SRFM - IASI",
                        color="tab:red",
                    )
                    plt.xlabel(r"Wavenumbers (cm$^{-1}$)")
                    plt.ylabel("Brightness-temperature difference (K)")
                    plt.legend()
                    plt.title(title)
                    plt.savefig(
                        os.path.join(
                            inp.values["results_fldr"],
                            f"{keystr}_diff_{suffix}.png",
                        )
                    )
                    if inp.values["show_plots"] == True:
                        plt.show()
                    plt.close()

    if inp.values["base_plots"] == True and "uu" in requested_outputs:
        _plot_spectral_outputs(
            model_SRFM,
            inp.values["results_fldr"],
            "rad",
            inp.values["show_plots"],
            filename_prefix=f"{keystr}_rad",
        )

    if inp.values["base_plots"] == True and not requested_outputs.intersection(
        {"bbt", "uu"}
    ):
        warnings.warn(
            "base_plots is True, but retain_outputs contains neither bbt nor "
            "radiance; no base plots were created.",
            stacklevel=2,
        )

    return model_SRFM
